"""SpendWise AI - Personal Expense Category Predictor
Interactive Full-Stack Streamlit Web Application

Understand your spending. Stay in control.
Polished, privacy-focused financial analytics & AI expense categorization.
"""

import io
import os
import sys
from datetime import date, datetime
import pandas as pd
import numpy as np
import streamlit as st
import altair as alt

# Ensure spendwise-ai root is in sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.preprocessing import clean_dataset, clean_text
from src.baseline import RuleBasedBaselineClassifier
from src.predict import predict_single, predict_batch, load_model, ModelNotFoundError
from src.analytics import (
    calculate_kpis,
    get_monthly_trend,
    get_category_breakdown,
    filter_transactions,
)
from src.privacy import sanitize_text, validate_csv_upload, get_privacy_audit_summary
from src.evaluation import evaluate_models_on_test_data, generate_evaluation_plots

# Page Configuration
st.set_page_config(
    page_title="SpendWise AI — Expense Category Predictor",
    page_icon="💳",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Load custom CSS
css_path = os.path.join(BASE_DIR, "assets", "styles.css")
if os.path.exists(css_path):
    with open(css_path, "r", encoding="utf-8") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

CATEGORIES_LIST = [
    "Food & Dining",
    "Transportation",
    "Shopping",
    "Bills & Utilities",
    "Healthcare",
    "Entertainment",
    "Education",
    "Groceries",
    "Travel",
    "Personal Care",
    "Housing",
    "Income",
    "Other",
]


@st.cache_resource
def get_cached_model():
    """Load and cache the trained ML model pipeline."""
    try:
        return load_model()
    except ModelNotFoundError:
        return None
    except Exception as exc:
        st.error(f"Error loading model: {exc}")
        return None


def init_session_state():
    """Initialize persistent session variables for active demo transactions."""
    if "transactions" not in st.session_state:
        csv_path = os.path.join(BASE_DIR, "data", "synthetic_transactions.csv")
        if os.path.exists(csv_path):
            raw_df = pd.read_csv(csv_path)
            clean_df, _ = clean_dataset(raw_df)
            # Add prediction & correction tracking columns
            model = get_cached_model()
            if model is not None:
                classified_df = predict_batch(clean_df, model=model)
            else:
                classified_df = clean_df.copy()
                classified_df["predicted_category"] = classified_df.get("category", "Other")
                classified_df["final_category"] = classified_df["predicted_category"]
                classified_df["confidence"] = 1.0
                classified_df["needs_review"] = False
                classified_df["review_status"] = "Auto-Approved"
                classified_df["manually_corrected"] = False
            st.session_state["transactions"] = classified_df
        else:
            st.session_state["transactions"] = pd.DataFrame(columns=[
                "transaction_id", "transaction_date", "description", "amount",
                "transaction_type", "category", "predicted_category",
                "final_category", "confidence", "needs_review", "review_status", "manually_corrected"
            ])

    if "confidence_threshold" not in st.session_state:
        st.session_state["confidence_threshold"] = 0.65


init_session_state()
model = get_cached_model()

# --- SIDEBAR NAVIGATION ---
with st.sidebar:
    st.markdown("""
    <div style="padding: 10px 0 16px 0;">
        <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 1.6rem;">💳</span>
            <span style="font-size: 1.35rem; font-weight: 800; letter-spacing: -0.02em; color: #ffffff;">SpendWise <span style="color: #2dd4bf;">AI</span></span>
        </div>
        <p style="font-size: 0.8rem; color: #94a3b8; margin: 4px 0 0 0;">Personal Expense Category Predictor</p>
    </div>
    """, unsafe_allow_html=True)

    page = st.radio(
        "Navigation",
        [
            "Overview",
            "Transactions",
            "Categorize Expenses",
            "Analytics",
            "Model Evaluation",
            "Privacy & About",
        ],
        label_visibility="collapsed",
    )

    st.markdown("---")
    st.markdown("<p style='font-size: 0.8rem; font-weight: 600; color: #94a3b8; text-transform: uppercase;'>Confidence Threshold</p>", unsafe_allow_html=True)
    new_threshold = st.slider(
        "Review Threshold",
        min_value=0.40,
        max_value=0.95,
        value=st.session_state["confidence_threshold"],
        step=0.05,
        help="Transactions with model probability below this threshold are flagged for manual review.",
    )
    if new_threshold != st.session_state["confidence_threshold"]:
        st.session_state["confidence_threshold"] = new_threshold
        # Update review flags dynamically
        df = st.session_state["transactions"]
        if not df.empty and "confidence" in df.columns:
            df["needs_review"] = df["confidence"] < new_threshold
            df["review_status"] = df["needs_review"].apply(lambda r: "Needs Review" if r else "Auto-Approved")
            st.session_state["transactions"] = df

    st.markdown("---")
    st.markdown("""
    <div style="font-size: 0.75rem; color: #64748b; line-height: 1.4;">
        <span style="color: #10b981;">●</span> <strong>Local Execution Mode</strong><br>
        Zero external AI API calls.<br>
        Synthetic demonstration data.
    </div>
    """, unsafe_allow_html=True)


# ==============================================================================
# 1. OVERVIEW PAGE
# ==============================================================================
if page == "Overview":
    st.markdown("""
    <div class="brand-header">
        <div>
            <div style="display: flex; align-items: center; gap: 10px;">
                <h1 class="brand-title">Financial Intelligence Overview</h1>
                <span class="brand-badge">Live Demo</span>
            </div>
            <p class="brand-subtitle">Real-time spending metrics, automated category predictions, and review queues.</p>
        </div>
    </div>
    """, unsafe_allow_html=True)

    df_active = st.session_state["transactions"]
    kpis = calculate_kpis(df_active)

    # 4 Metric Cards
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(f"""
        <div class="kpi-card kpi-expense">
            <div class="kpi-label">Total Outbound Expenses</div>
            <div class="kpi-value">${kpis['total_expenses']:,.2f}</div>
            <div class="kpi-subtext">{kpis['expense_count']} transactions</div>
        </div>
        """, unsafe_allow_html=True)
    with c2:
        st.markdown(f"""
        <div class="kpi-card kpi-income">
            <div class="kpi-label">Total Inbound Income</div>
            <div class="kpi-value">${kpis['total_income']:,.2f}</div>
            <div class="kpi-subtext">{kpis['income_count']} deposits & salary</div>
        </div>
        """, unsafe_allow_html=True)
    with c3:
        st.markdown(f"""
        <div class="kpi-card kpi-savings">
            <div class="kpi-label">Net Monthly Cashflow</div>
            <div class="kpi-value">${kpis['net_savings']:,.2f}</div>
            <div class="kpi-subtext">Income minus expenses</div>
        </div>
        """, unsafe_allow_html=True)
    with c4:
        st.markdown(f"""
        <div class="kpi-card kpi-review">
            <div class="kpi-label">Awaiting Verification</div>
            <div class="kpi-value">{kpis['needs_review_count']}</div>
            <div class="kpi-subtext">Confidence &lt; {st.session_state['confidence_threshold']*100:.0f}%</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # Overview Charts Row
    chart_col1, chart_col2 = st.columns([1.4, 1.0])

    with chart_col1:
        st.markdown("<div class='section-heading'>📈 Monthly Spending & Income Trend</div>", unsafe_allow_html=True)
        trend_df = get_monthly_trend(df_active)
        if not trend_df.empty:
            chart_data = pd.melt(
                trend_df,
                id_vars=["month"],
                value_vars=["expenses", "income"],
                var_name="Type",
                value_name="Amount ($)",
            )
            chart = alt.Chart(chart_data).mark_bar(cornerRadiusTopLeft=4, cornerRadiusTopRight=4).encode(
                x=alt.X("month:N", title="Month (YYYY-MM)", axis=alt.Axis(labelAngle=-45)),
                y=alt.Y("Amount ($):Q", title="Total Amount ($)"),
                color=alt.Color("Type:N", scale=alt.Scale(domain=["expenses", "income"], range=["#f43f5e", "#10b981"])),
                xOffset="Type:N",
                tooltip=["month", "Type", alt.Tooltip("Amount ($):Q", format="$,.2f")]
            ).properties(height=320)
            st.altair_chart(chart, use_container_width=True)
        else:
            st.info("No transaction data available to plot monthly trends.")

    with chart_col2:
        st.markdown("<div class='section-heading'>🍩 Expense Distribution</div>", unsafe_allow_html=True)
        cat_df = get_category_breakdown(df_active)
        if not cat_df.empty:
            donut = alt.Chart(cat_df).mark_arc(innerRadius=60).encode(
                theta=alt.Theta("total_amount:Q"),
                color=alt.Color("category:N", scale=alt.Scale(scheme="tealblues"), legend=alt.Legend(columns=2, orient="bottom")),
                tooltip=["category", alt.Tooltip("total_amount:Q", format="$,.2f"), alt.Tooltip("percentage:Q", format=".1f%")]
            ).properties(height=320)
            st.altair_chart(donut, use_container_width=True)
        else:
            st.info("No expense categories found in active session.")

    st.markdown("<div style='height: 15px;'></div>", unsafe_allow_html=True)

    # Bottom Row: Review Queue & Recent Transactions
    t1, t2 = st.columns([1.1, 0.9])
    with t1:
        st.markdown("<div class='section-heading'>🔍 Review Queue (Low Confidence / Ambiguous)</div>", unsafe_allow_html=True)
        review_df = df_active[df_active["needs_review"] == True]
        if not review_df.empty:
            st.markdown(f"<p style='font-size: 0.85rem; color: #64748b; margin-top:-10px;'>{len(review_df)} transactions recommended for manual confirmation:</p>", unsafe_allow_html=True)
            display_cols = ["transaction_id", "transaction_date", "description", "amount", "predicted_category", "confidence"]
            st.dataframe(
                review_df[display_cols].head(8).style.format({"amount": "${:,.2f}", "confidence": "{:.1%}"}),
                use_container_width=True,
                height=260,
            )
        else:
            st.success("🎉 All active transactions meet the confidence threshold. No items currently need review.")

    with t2:
        st.markdown("<div class='section-heading'>⚡ Model Performance Summary</div>", unsafe_allow_html=True)
        metrics_file = os.path.join(BASE_DIR, "models", "evaluation_summary.json")
        if os.path.exists(metrics_file):
            import json
            with open(metrics_file, "r") as mf:
                m_data = json.load(mf)
            st.markdown(f"""
            <div class="content-card" style="padding: 16px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <span style="font-size: 0.85rem; color: #64748b;">Architecture:</span>
                    <strong style="font-size: 0.85rem;">{m_data.get('model_type', 'TF-IDF + Logistic Regression')}</strong>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <span style="font-size: 0.85rem; color: #64748b;">Test Set Accuracy:</span>
                    <strong style="font-size: 0.9rem; color: #0d9488;">{m_data.get('ml_accuracy', 0.0)*100:.1f}%</strong>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <span style="font-size: 0.85rem; color: #64748b;">Macro F1-Score:</span>
                    <strong style="font-size: 0.9rem; color: #0d9488;">{m_data.get('ml_macro_f1', 0.0)*100:.1f}%</strong>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <span style="font-size: 0.85rem; color: #64748b;">Baseline Comparison:</span>
                    <strong style="font-size: 0.85rem; color: #64748b;">+{((m_data.get('ml_accuracy',0)-m_data.get('baseline_accuracy',0))*100):.1f}% over rules</strong>
                </div>
                <div style="font-size: 0.78rem; color: #94a3b8; margin-top: 10px;">
                    Evaluated on {m_data.get('test_samples', 0)} stratified, held-out test transactions.
                </div>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.info("Run `python -m src.train_model` to generate complete evaluation statistics.")


# ==============================================================================
# 2. TRANSACTIONS PAGE
# ==============================================================================
elif page == "Transactions":
    st.markdown("""
    <div class="brand-header">
        <div>
            <h1 class="brand-title">Transaction Ledger & Manual Overrides</h1>
            <p class="brand-subtitle">Search, filter, edit categories, and export records with full audit traceability.</p>
        </div>
    </div>
    """, unsafe_allow_html=True)

    df_active = st.session_state["transactions"]

    # Filter Bar
    with st.expander("🔍 Search & Filter Controls", expanded=True):
        f1, f2, f3, f4 = st.columns([1.5, 1.2, 1.0, 1.0])
        with f1:
            search_query = st.text_input("Search Description or ID", placeholder="e.g. Starbucks, Uber, Kroger, TXN-1002")
        with f2:
            cat_filter = st.multiselect("Filter by Category", options=CATEGORIES_LIST, default=[])
        with f3:
            type_filter = st.selectbox("Transaction Type", ["All", "Expense", "Income"])
        with f4:
            sort_choice = st.selectbox(
                "Sort Order",
                ["Date (Newest)", "Date (Oldest)", "Amount (Highest)", "Amount (Lowest)"]
            )

    filtered_df = filter_transactions(
        df_active,
        search_query=search_query,
        selected_categories=cat_filter,
        transaction_type=type_filter,
        sort_by=sort_choice,
    )

    st.markdown(f"<p style='font-size: 0.88rem; color: #475569; font-weight: 500;'>Showing <strong>{len(filtered_df)}</strong> of {len(df_active)} transactions</p>", unsafe_allow_html=True)

    # Interactive Category Correction Section
    st.markdown("<div class='section-heading'>✏️ Edit Transaction Category</div>", unsafe_allow_html=True)
    if not filtered_df.empty:
        col_select, col_new_cat, col_btn = st.columns([2, 1.5, 1])
        with col_select:
            selected_txn_id = st.selectbox(
                "Select Transaction to Correct",
                options=filtered_df["transaction_id"].tolist(),
                format_func=lambda x: f"{x} — {filtered_df[filtered_df['transaction_id'] == x]['description'].values[0]} (${filtered_df[filtered_df['transaction_id'] == x]['amount'].values[0]:.2f})",
            )
        current_row = filtered_df[filtered_df["transaction_id"] == selected_txn_id].iloc[0]
        with col_new_cat:
            new_cat = st.selectbox(
                "Assign New Category",
                options=CATEGORIES_LIST,
                index=CATEGORIES_LIST.index(current_row["final_category"]) if current_row["final_category"] in CATEGORIES_LIST else 0,
            )
        with col_btn:
            st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True)
            if st.button("Apply Correction", type="primary"):
                # Update in st.session_state
                idx = st.session_state["transactions"].index[st.session_state["transactions"]["transaction_id"] == selected_txn_id].tolist()
                if idx:
                    target_idx = idx[0]
                    st.session_state["transactions"].at[target_idx, "final_category"] = new_cat
                    st.session_state["transactions"].at[target_idx, "manually_corrected"] = True
                    st.session_state["transactions"].at[target_idx, "needs_review"] = False
                    st.session_state["transactions"].at[target_idx, "review_status"] = "Verified"
                    st.success(f"Updated {selected_txn_id} to '{new_cat}'. Analytics updated dynamically!")
                    st.rerun()

    # Data Table View
    display_cols = [
        "transaction_id", "transaction_date", "description", "amount",
        "transaction_type", "predicted_category", "final_category",
        "confidence", "review_status", "manually_corrected"
    ]
    present_cols = [c for c in display_cols if c in filtered_df.columns]
    
    st.dataframe(
        filtered_df[present_cols].style.format({
            "amount": "${:,.2f}",
            "confidence": "{:.1%}",
        }),
        use_container_width=True,
        height=380,
    )

    # Action buttons: Add transaction, Delete, CSV Export
    a1, a2, a3 = st.columns([1, 1, 1])
    with a1:
        # Export CSV
        csv_buffer = io.StringIO()
        filtered_df.to_csv(csv_buffer, index=False)
        st.download_button(
            label="📥 Export Ledger to CSV",
            data=csv_buffer.getvalue(),
            file_name=f"spendwise_ledger_{date.today()}.csv",
            mime="text/csv",
        )
    with a2:
        with st.popover("➕ Add Transaction"):
            st.markdown("### Add Synthetic Transaction")
            new_desc = st.text_input("Description", "Kroger organic fruit")
            new_amt = st.number_input("Amount ($)", min_value=0.01, value=25.50, step=1.0)
            new_date = st.date_input("Date", date.today())
            new_type = st.selectbox("Type", ["expense", "income"])
            if st.button("Save Transaction", key="save_new_txn"):
                pred_res = predict_single(new_desc, amount=new_amt, model=model, threshold=st.session_state["confidence_threshold"])
                new_row = {
                    "transaction_id": f"TXN-{np.random.randint(20000, 99999)}",
                    "transaction_date": str(new_date),
                    "description": new_desc,
                    "amount": float(new_amt),
                    "transaction_type": new_type,
                    "category": pred_res["predicted_category"],
                    "predicted_category": pred_res["predicted_category"],
                    "final_category": pred_res["predicted_category"],
                    "confidence": pred_res["confidence"],
                    "needs_review": pred_res["needs_review"],
                    "review_status": pred_res["review_status"],
                    "manually_corrected": False,
                }
                st.session_state["transactions"] = pd.concat(
                    [st.session_state["transactions"], pd.DataFrame([new_row])],
                    ignore_index=True
                )
                st.success("New transaction added and classified!")
                st.rerun()

    with a3:
        with st.popover("🗑️ Delete Transaction"):
            del_id = st.selectbox("Transaction ID to Delete", options=filtered_df["transaction_id"].tolist()) if not filtered_df.empty else None
            if del_id and st.button("Confirm Delete", type="secondary"):
                st.session_state["transactions"] = st.session_state["transactions"][
                    st.session_state["transactions"]["transaction_id"] != del_id
                ].reset_index(drop=True)
                st.warning(f"Deleted {del_id}.")
                st.rerun()


# ==============================================================================
# 3. CATEGORIZE EXPENSES PAGE
# ==============================================================================
elif page == "Categorize Expenses":
    st.markdown("""
    <div class="brand-header">
        <div>
            <h1 class="brand-title">AI Expense Categorization Engine</h1>
            <p class="brand-subtitle">Classify single purchases instantly or run batch categorization on uploaded CSV statements.</p>
        </div>
    </div>
    """, unsafe_allow_html=True)

    tab_single, tab_bulk = st.tabs(["⚡ Single Transaction Predictor", "📁 Batch Statement Upload"])

    # TAB 1: Single Prediction
    with tab_single:
        st.markdown("<div class='section-heading'>Predict Expense Category</div>", unsafe_allow_html=True)
        with st.form("single_predict_form"):
            col_d, col_a = st.columns([2.5, 1])
            with col_d:
                user_desc = st.text_input(
                    "Transaction Description",
                    placeholder="e.g. Starbucks Cafe #1042, Uber Ride to SFO, ConEdison Electric Bill",
                    help="Enter merchant details or bank narrative. Text is sanitized and checked locally.",
                )
            with col_a:
                user_amount = st.number_input(
                    "Amount ($)",
                    min_value=0.01,
                    value=18.50,
                    step=1.0,
                    format="%.2f",
                )
            col_dt, col_tp = st.columns([1, 1])
            with col_dt:
                user_date = st.date_input("Transaction Date", date.today())
            with col_tp:
                user_type = st.selectbox("Type", ["expense", "income"])

            predict_submitted = st.form_submit_button("Predict Category", type="primary")

        if predict_submitted:
            if not user_desc.strip():
                st.error("Please provide a valid, non-empty transaction description.")
            else:
                # Sanitization & Inference
                sanitized_input = sanitize_text(user_desc)
                result = predict_single(
                    sanitized_input,
                    amount=user_amount,
                    model=model,
                    threshold=st.session_state["confidence_threshold"],
                )
                st.session_state["last_prediction"] = result
                st.session_state["last_prediction"]["date"] = str(user_date)
                st.session_state["last_prediction"]["type"] = user_type

        # Display result if available
        if "last_prediction" in st.session_state:
            pred = st.session_state["last_prediction"]
            conf = pred["confidence"]
            needs_rev = pred["needs_review"]

            st.markdown(f"""
            <div class="prediction-box">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-size: 0.85rem; font-weight: 700; color: #64748b; text-transform: uppercase;">Prediction Result</span>
                    <span class="badge {'badge-review' if needs_rev else 'badge-approved'}">
                        {'⚠️ Needs Manual Review' if needs_rev else '✓ High Confidence'}
                    </span>
                </div>
                <div style="font-size: 2.2rem; font-weight: 800; color: #0d9488; margin: 8px 0;">
                    {pred['predicted_category']}
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 0.88rem; color: #475569;">
                    <span>Estimated Confidence: <strong>{pred['confidence_percentage']}</strong></span>
                    <span>Review Threshold: <strong>{st.session_state['confidence_threshold']*100:.0f}%</strong></span>
                </div>
                <div class="confidence-bar-wrapper">
                    <div class="confidence-bar-fill" style="width: {min(100, int(conf * 100))}%;"></div>
                </div>
                <p style="font-size: 0.86rem; color: #64748b; margin-top: 8px;">
                    {pred['review_reason']}
                </p>
            </div>
            """, unsafe_allow_html=True)

            # Probabilities distribution
            if pred["top_probabilities"]:
                st.markdown("<p style='font-size: 0.85rem; font-weight: 600; color: #475569;'>Top Category Probabilities:</p>", unsafe_allow_html=True)
                top_p_df = pd.DataFrame(pred["top_probabilities"])
                st.dataframe(top_p_df.style.format({"probability": "{:.1%}"}), use_container_width=True, height=140)

            # Option to manually override and save
            st.markdown("#### Confirm & Add to Ledger")
            ov_c1, ov_c2 = st.columns([2, 1])
            with ov_c1:
                override_choice = st.selectbox(
                    "Override or Confirm Category",
                    options=CATEGORIES_LIST,
                    index=CATEGORIES_LIST.index(pred["predicted_category"]) if pred["predicted_category"] in CATEGORIES_LIST else 0,
                    key="override_selector",
                )
            with ov_c2:
                st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True)
                if st.button("Save to Ledger", type="primary", key="save_single_to_ledger"):
                    is_corrected = override_choice != pred["predicted_category"]
                    new_record = {
                        "transaction_id": f"TXN-{np.random.randint(10000, 99999)}",
                        "transaction_date": pred["date"],
                        "description": pred["description"],
                        "amount": float(pred["amount"]),
                        "transaction_type": pred["type"],
                        "category": pred["predicted_category"],
                        "predicted_category": pred["predicted_category"],
                        "final_category": override_choice,
                        "confidence": pred["confidence"],
                        "needs_review": False if is_corrected else pred["needs_review"],
                        "review_status": "Verified" if is_corrected else pred["review_status"],
                        "manually_corrected": is_corrected,
                    }
                    st.session_state["transactions"] = pd.concat(
                        [st.session_state["transactions"], pd.DataFrame([new_record])],
                        ignore_index=True
                    )
                    st.success(f"Saved to ledger with final category '{override_choice}'!")

    # TAB 2: Batch Statement Upload
    with tab_bulk:
        st.markdown("<div class='section-heading'>Batch CSV Upload & Classification</div>", unsafe_allow_html=True)
        st.markdown("<p style='font-size: 0.9rem; color: #475569;'>Upload a CSV file containing transactions. Required column: <code>description</code>. Optional columns: <code>amount</code>, <code>transaction_date</code>, <code>transaction_type</code>.</p>", unsafe_allow_html=True)

        # Download Template Button
        template_csv = "description,amount,transaction_date,transaction_type\nStarbucks Coffee,5.40,2026-10-15,expense\nUber Ride Downtown,22.50,2026-10-16,expense\nKroger Weekly Groceries,115.80,2026-10-17,expense\nTechCorp Payroll Deposit,3200.00,2026-10-18,income\nVerizon Wireless Bill,65.00,2026-10-19,expense\n"
        st.download_button(
            label="📄 Download Sample CSV Template",
            data=template_csv,
            file_name="spendwise_template.csv",
            mime="text/csv",
        )

        uploaded_file = st.file_uploader("Choose CSV file", type=["csv"])
        if uploaded_file is not None:
            try:
                raw_upload_df = pd.read_csv(uploaded_file)
                valid, msg, validated_df = validate_csv_upload(raw_upload_df)
                if not valid:
                    st.error(f"Validation failed: {msg}")
                else:
                    st.success(f"Validation passed! {len(validated_df)} rows ready for classification.")
                    
                    if st.button("Run Batch AI Classification", type="primary"):
                        with st.spinner("Processing text and running ML inference..."):
                            batch_results = predict_batch(
                                validated_df,
                                model=model,
                                threshold=st.session_state["confidence_threshold"],
                            )
                            st.session_state["batch_results"] = batch_results

                    if "batch_results" in st.session_state:
                        res_df = st.session_state["batch_results"]
                        st.markdown("#### Classified Transactions Preview:")
                        st.dataframe(
                            res_df[["transaction_id", "transaction_date", "description", "amount", "predicted_category", "confidence", "review_status"]].style.format({"amount": "${:,.2f}", "confidence": "{:.1%}"}),
                            use_container_width=True,
                            height=300,
                        )

                        if st.button("📥 Import All into Active Ledger", type="primary"):
                            st.session_state["transactions"] = pd.concat(
                                [st.session_state["transactions"], res_df],
                                ignore_index=True
                            ).drop_duplicates(subset=["transaction_id"]).reset_index(drop=True)
                            st.success(f"Imported {len(res_df)} transactions into active session ledger!")
                            del st.session_state["batch_results"]
                            st.rerun()

            except Exception as e:
                st.error(f"Error parsing uploaded CSV: {e}")


# ==============================================================================
# 4. ANALYTICS PAGE
# ==============================================================================
elif page == "Analytics":
    st.markdown("""
    <div class="brand-header">
        <div>
            <h1 class="brand-title">Spending Analytics & Budget Breakdown</h1>
            <p class="brand-subtitle">Interactive financial charts derived from real dataset records and user category confirmations.</p>
        </div>
    </div>
    """, unsafe_allow_html=True)

    df_active = st.session_state["transactions"]
    kpis = calculate_kpis(df_active)

    # Top metrics
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Total Expenses", f"${kpis['total_expenses']:,.2f}")
    m2.metric("Total Income", f"${kpis['total_income']:,.2f}")
    m3.metric("Net Savings", f"${kpis['net_savings']:,.2f}")
    m4.metric("Top Expense Category", kpis['top_category'])

    st.markdown("---")

    # Chart 1: Category Total Expenditure Bar Chart
    cat_df = get_category_breakdown(df_active)
    if not cat_df.empty:
        c1, c2 = st.columns([1.2, 1.0])
        with c1:
            st.markdown("<div class='section-heading'>📊 Total Spending by Category</div>", unsafe_allow_html=True)
            bar_chart = alt.Chart(cat_df).mark_bar(cornerRadius=4, color="#0d9488").encode(
                x=alt.X("total_amount:Q", title="Total Amount ($)"),
                y=alt.Y("category:N", sort="-x", title="Category"),
                tooltip=["category", alt.Tooltip("total_amount:Q", format="$,.2f"), alt.Tooltip("percentage:Q", format=".1f%")]
            ).properties(height=380)
            st.altair_chart(bar_chart, use_container_width=True)

        with c2:
            st.markdown("<div class='section-heading'>💰 Average Spend Per Transaction</div>", unsafe_allow_html=True)
            avg_chart = alt.Chart(cat_df).mark_bar(cornerRadius=4, color="#3b82f6").encode(
                x=alt.X("average_amount:Q", title="Average Transaction ($)"),
                y=alt.Y("category:N", sort="-x", title="Category"),
                tooltip=["category", alt.Tooltip("average_amount:Q", format="$,.2f"), "count"]
            ).properties(height=380)
            st.altair_chart(avg_chart, use_container_width=True)

        st.markdown("<div style='height: 15px;'></div>", unsafe_allow_html=True)

        # Category Statistics Summary Table
        st.markdown("<div class='section-heading'>📋 Detailed Category Spending Table</div>", unsafe_allow_html=True)
        st.dataframe(
            cat_df.style.format({
                "total_amount": "${:,.2f}",
                "average_amount": "${:,.2f}",
                "percentage": "{:.1f}%",
            }),
            use_container_width=True,
            height=300,
        )

    else:
        st.info("No expense transactions found in the active session dataset.")


# ==============================================================================
# 5. MODEL EVALUATION PAGE
# ==============================================================================
elif page == "Model Evaluation":
    st.markdown("""
    <div class="brand-header">
        <div>
            <h1 class="brand-title">Machine Learning Model Diagnostics</h1>
            <p class="brand-subtitle">Rigorous empirical evaluation comparing Scikit-Learn TF-IDF Logistic Regression against Rule-Based Baseline.</p>
        </div>
    </div>
    """, unsafe_allow_html=True)

    metrics_file = os.path.join(BASE_DIR, "models", "evaluation_summary.json")
    if os.path.exists(metrics_file):
        import json
        with open(metrics_file, "r") as mf:
            summary = json.load(mf)

        # Overview Metrics Cards
        ev1, ev2, ev3, ev4 = st.columns(4)
        ev1.metric("ML Test Accuracy", f"{summary['ml_accuracy']*100:.1f}%", f"+{(summary['ml_accuracy'] - summary['baseline_accuracy'])*100:.1f}% vs Rules")
        ev2.metric("ML Macro F1-Score", f"{summary['ml_macro_f1']*100:.1f}%", f"+{(summary['ml_macro_f1'] - summary['baseline_macro_f1'])*100:.1f}% vs Rules")
        ev3.metric("Baseline Rule Accuracy", f"{summary['baseline_accuracy']*100:.1f}%")
        ev4.metric("Held-Out Test Records", f"{summary['test_samples']} samples")

        st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

        # Visual Plots Grid
        plot_dir = os.path.join(BASE_DIR, "assets", "plots")
        p_cm = os.path.join(plot_dir, "confusion_matrix.png")
        p_f1 = os.path.join(plot_dir, "per_category_f1.png")
        p_cmp = os.path.join(plot_dir, "model_comparison.png")
        p_dist = os.path.join(plot_dir, "category_distribution.png")

        # Row 1: Confusion Matrix and Overall Comparison
        c1, c2 = st.columns([1.1, 0.9])
        with c1:
            if os.path.exists(p_cm):
                st.image(p_cm, caption="Confusion Matrix: True Ground Truth vs Model Predictions", use_container_width=True)
            else:
                st.info("Confusion matrix plot not found. Run evaluation to regenerate.")
        with c2:
            if os.path.exists(p_cmp):
                st.image(p_cmp, caption="Overall Accuracy and F1 Comparison", use_container_width=True)
            else:
                st.info("Comparison chart not found.")

        # Row 2: Per-Category F1 and Class Support
        c3, c4 = st.columns([1.2, 0.8])
        with c3:
            if os.path.exists(p_f1):
                st.image(p_f1, caption="Per-Category F1 Score Comparison", use_container_width=True)
        with c4:
            if os.path.exists(p_dist):
                st.image(p_dist, caption="Test Set Stratified Distribution", use_container_width=True)

        # Classification Report Table
        st.markdown("<div class='section-heading'>📄 Detailed Classification Report</div>", unsafe_allow_html=True)
        rep = summary.get("classification_report", {})
        if rep:
            rep_rows = []
            for k, v in rep.items():
                if isinstance(v, dict):
                    rep_rows.append({
                        "Category / Metric": k,
                        "Precision": round(v.get("precision", 0.0), 3),
                        "Recall": round(v.get("recall", 0.0), 3),
                        "F1-Score": round(v.get("f1-score", 0.0), 3),
                        "Support": int(v.get("support", 0)),
                    })
            st.dataframe(pd.DataFrame(rep_rows), use_container_width=True, height=350)

    else:
        st.warning("Model evaluation metrics not yet generated. Please run `python -m src.train_model`.")


# ==============================================================================
# 6. PRIVACY & ABOUT PAGE
# ==============================================================================
elif page == "Privacy & About":
    st.markdown("""
    <div class="brand-header">
        <div>
            <h1 class="brand-title">Privacy Architecture & Responsible AI</h1>
            <p class="brand-subtitle">Understanding local data processing, PII redaction, and project scope.</p>
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class="privacy-banner">
        <strong>🔒 Privacy Guarantee:</strong> SpendWise AI operates exclusively within this local application runtime.
        Zero transaction descriptions or monetary amounts are transmitted to third-party AI APIs or external clouds.
    </div>
    """, unsafe_allow_html=True)

    col_info1, col_info2 = st.columns(2)

    with col_info1:
        st.markdown("""
        ### Responsible AI Principles
        1. **Local Processing**:
           NLP text vectorization and logistic regression inference execute on the local machine via scikit-learn. No cloud API calls (e.g. OpenAI, Anthropic, or Google) are initiated.
        2. **Synthetic Data Standard**:
           The application comes seeded with synthetic banking transactions. Real online banking logins, account credentials, or passwords are **never requested or stored**.
        3. **Confidence-Gated Automation**:
           Predictions below the user-controlled certainty threshold are highlighted with a *Needs Review* banner, preventing automated over-confidence.
        4. **Human-in-the-Loop Overrides**:
           Users can override any model prediction. Manually corrected categories take immediate precedence in all analytics and reports.
        """)

    with col_info2:
        st.markdown("""
        ### Automatic PII Redaction Demo
        Try typing any text containing credit card numbers, SSNs, or account numbers below to see the regex sanitation filter in action:
        """)
        pii_test = st.text_input("Enter sample narrative with sensitive info:", "Paid $45 with card 4532-1111-2222-3333 at supermarket")
        sanitized_res = sanitize_text(pii_test)
        st.code(f"Sanitized: {sanitized_res}")

        st.markdown("### Reset Active Demo Session")
        st.markdown("Restore the session ledger to clean default synthetic transactions:")
        if st.button("Reset Active Demo Session Data", type="secondary"):
            if "transactions" in st.session_state:
                del st.session_state["transactions"]
            init_session_state()
            st.success("Session state successfully reset to original clean dataset.")
            st.rerun()

    st.markdown("---")
    st.markdown("""
    <div style="font-size: 0.85rem; color: #64748b; line-height: 1.5;">
        <strong>Project Notice & Disclaimer:</strong> SpendWise AI is an academic machine-learning capstone project. Financial analytics, category breakdowns, and monthly projections are provided strictly for informational and demonstration purposes and do not constitute certified financial or accounting advice.
    </div>
    """, unsafe_allow_html=True)
