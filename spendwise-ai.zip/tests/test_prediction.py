"""SpendWise AI - Prediction & Classification Engine Unit Tests"""

import pandas as pd
import pytest

from src.baseline import RuleBasedBaselineClassifier
from src.predict import predict_single, predict_batch, load_model


def test_baseline_classifier_known_rules():
    """Verify that rule-based classifier correctly resolves core categories."""
    baseline = RuleBasedBaselineClassifier()

    assert baseline.predict_single("Starbucks Coffee")["predicted_category"] == "Food & Dining"
    assert baseline.predict_single("Uber Trip rideshare")["predicted_category"] == "Transportation"
    assert baseline.predict_single("Kroger Supermarket groceries")["predicted_category"] == "Groceries"
    assert baseline.predict_single("Netflix monthly subscription")["predicted_category"] == "Entertainment"
    assert baseline.predict_single("Apartment monthly rent")["predicted_category"] == "Housing"
    assert baseline.predict_single("Employer bi-weekly salary deposit")["predicted_category"] == "Income"


def test_baseline_classifier_unmatched_fallback():
    """Verify fallback when no rule matches."""
    baseline = RuleBasedBaselineClassifier()
    res = baseline.predict_single("XyZ999 Unknown Mystery Vendor")
    assert res["predicted_category"] == "Other"
    assert res["confidence"] == 0.0


def test_ml_predict_single_structure():
    """Verify ML prediction returns all expected fields, confidence, and top probabilities."""
    res = predict_single("Trader Joe's organic vegetables produce", amount=45.50)
    assert "predicted_category" in res
    assert "confidence" in res
    assert "needs_review" in res
    assert "top_probabilities" in res
    assert isinstance(res["confidence"], float)
    assert 0.0 <= res["confidence"] <= 1.0
    assert len(res["top_probabilities"]) > 0


def test_ml_predict_single_empty_input():
    """Verify robust handling of empty text."""
    res = predict_single("")
    assert res["predicted_category"] == "Other"
    assert res["confidence"] == 0.0
    assert res["needs_review"] is True


def test_ml_predict_batch():
    """Verify batch inference appends expected columns to DataFrame."""
    batch_df = pd.DataFrame([
        {"transaction_id": "TXN-1", "description": "Delta Air Lines flight booking", "amount": 320.0},
        {"transaction_id": "TXN-2", "description": "CVS Pharmacy medicine", "amount": 22.0},
    ])
    result_df = predict_batch(batch_df)
    assert "predicted_category" in result_df.columns
    assert "confidence" in result_df.columns
    assert "review_status" in result_df.columns
    assert "final_category" in result_df.columns
    assert len(result_df) == 2
