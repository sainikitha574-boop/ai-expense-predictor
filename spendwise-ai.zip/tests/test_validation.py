"""SpendWise AI - Validation, Privacy, and Analytics Unit Tests"""

import pandas as pd
import pytest

from src.privacy import sanitize_text, validate_csv_upload
from src.analytics import calculate_kpis, get_monthly_trend, filter_transactions


def test_sanitize_text_pii_redaction():
    """Verify that credit card numbers, SSNs, accounts, and emails are properly masked."""
    raw = "Paid $50 with card 4532-1234-5678-9010 at merchant"
    sanitized = sanitize_text(raw)
    assert "[REDACTED_CARD]" in sanitized
    assert "4532-1234-5678-9010" not in sanitized

    ssn_raw = "Identity check ref 123-45-6789"
    assert "[REDACTED_SSN]" in sanitize_text(ssn_raw)

    acct_raw = "ACH transfer to acct: 9876543210"
    assert "[REDACTED_ACCOUNT]" in sanitize_text(acct_raw)

    email_raw = "Sent receipt to test.user@example.com"
    assert "[REDACTED_EMAIL]" in sanitize_text(email_raw)


def test_validate_csv_upload_valid_file():
    """Verify CSV validation succeeds with required columns."""
    df = pd.DataFrame([
        {"description": "Whole Foods Market", "amount": 85.0, "transaction_date": "2026-03-15", "transaction_type": "expense"},
        {"description": "Uber Ride", "amount": 24.5, "transaction_date": "2026-03-16", "transaction_type": "expense"},
    ])
    valid, msg, validated_df = validate_csv_upload(df)
    assert valid is True
    assert len(validated_df) == 2
    assert "description" in validated_df.columns
    assert "transaction_id" in validated_df.columns


def test_validate_csv_upload_missing_required_column():
    """Verify validation fails when 'description' column is omitted."""
    df = pd.DataFrame([
        {"item": "Coffee", "cost": 5.0}
    ])
    valid, msg, _ = validate_csv_upload(df)
    assert valid is False
    assert "Missing required column 'description'" in msg


def test_calculate_kpis_separates_income_and_expenses():
    """Verify that income is NEVER combined into expenses."""
    sample_df = pd.DataFrame([
        {"transaction_id": "TXN-1", "transaction_date": "2026-05-01", "description": "Salary", "amount": 3000.0, "transaction_type": "income", "final_category": "Income"},
        {"transaction_id": "TXN-2", "transaction_date": "2026-05-02", "description": "Rent", "amount": 1200.0, "transaction_type": "expense", "final_category": "Housing"},
        {"transaction_id": "TXN-3", "transaction_date": "2026-05-03", "description": "Groceries", "amount": 300.0, "transaction_type": "expense", "final_category": "Groceries"},
    ])
    kpis = calculate_kpis(sample_df)
    assert kpis["total_income"] == 3000.0
    assert kpis["total_expenses"] == 1500.0
    assert kpis["net_savings"] == 1500.0
    assert kpis["top_category"] == "Housing"
    assert kpis["total_transactions"] == 3


def test_filter_transactions_query():
    """Verify transaction filtering by search text and category."""
    df = pd.DataFrame([
        {"transaction_id": "TXN-1", "transaction_date": "2026-05-01", "description": "Starbucks Coffee", "amount": 6.5, "transaction_type": "expense", "final_category": "Food & Dining"},
        {"transaction_id": "TXN-2", "transaction_date": "2026-05-02", "description": "Target Shoes", "amount": 45.0, "transaction_type": "expense", "final_category": "Shopping"},
    ])
    res = filter_transactions(df, search_query="starbucks")
    assert len(res) == 1
    assert res.iloc[0]["transaction_id"] == "TXN-1"
