"""SpendWise AI - Preprocessing and Data Cleaning Unit Tests"""

import pandas as pd
import numpy as np
import pytest

from src.preprocessing import clean_text, clean_dataset, inspect_dataset, prepare_training_data


def test_clean_text_normalization():
    """Test text lowercasing, whitespace trimming, and punctuation preservation."""
    assert clean_text("  STARBUCKS COFFEE #1042  ") == "starbucks coffee #1042"
    assert clean_text("Whole   Foods   Organic   Market") == "whole foods organic market"
    assert clean_text("---Netflix Monthly Subscription---") == "netflix monthly subscription"
    assert clean_text("") == ""
    assert clean_text(None) == ""
    assert clean_text(np.nan) == ""


def test_clean_dataset_removes_duplicates():
    """Verify that exact duplicate rows are detected and removed."""
    sample_data = pd.DataFrame([
        {"transaction_id": "TXN-1", "transaction_date": "2026-01-01", "description": "Uber Trip", "amount": 25.0, "transaction_type": "expense", "category": "Transportation"},
        {"transaction_id": "TXN-1", "transaction_date": "2026-01-01", "description": "Uber Trip", "amount": 25.0, "transaction_type": "expense", "category": "Transportation"},
        {"transaction_id": "TXN-2", "transaction_date": "2026-01-02", "description": "Target Store", "amount": 40.0, "transaction_type": "expense", "category": "Shopping"},
    ])
    cleaned, audit = clean_dataset(sample_data)
    assert len(cleaned) == 2
    assert audit["duplicates_removed"] == 1


def test_clean_dataset_rejects_invalid_amounts():
    """Verify that negative amounts, zero amounts, and non-numeric amounts are filtered."""
    sample_data = pd.DataFrame([
        {"transaction_id": "TXN-1", "transaction_date": "2026-01-01", "description": "Groceries", "amount": 50.0, "transaction_type": "expense", "category": "Groceries"},
        {"transaction_id": "TXN-2", "transaction_date": "2026-01-02", "description": "Refund Error", "amount": -20.0, "transaction_type": "expense", "category": "Groceries"},
        {"transaction_id": "TXN-3", "transaction_date": "2026-01-03", "description": "Zero Charge", "amount": 0.0, "transaction_type": "expense", "category": "Groceries"},
        {"transaction_id": "TXN-4", "transaction_date": "2026-01-04", "description": "Corrupt String", "amount": "invalid_num", "transaction_type": "expense", "category": "Groceries"},
    ])
    cleaned, audit = clean_dataset(sample_data)
    assert len(cleaned) == 1
    assert audit["invalid_amounts_removed"] == 3
    assert cleaned.iloc[0]["amount"] == 50.0


def test_clean_dataset_handles_empty_descriptions():
    """Verify that rows with null or whitespace-only descriptions are safely dropped."""
    sample_data = pd.DataFrame([
        {"transaction_id": "TXN-1", "transaction_date": "2026-01-01", "description": "Coffee", "amount": 5.0, "transaction_type": "expense", "category": "Food & Dining"},
        {"transaction_id": "TXN-2", "transaction_date": "2026-01-02", "description": "   ", "amount": 10.0, "transaction_type": "expense", "category": "Food & Dining"},
        {"transaction_id": "TXN-3", "transaction_date": "2026-01-03", "description": np.nan, "amount": 15.0, "transaction_type": "expense", "category": "Food & Dining"},
    ])
    cleaned, audit = clean_dataset(sample_data)
    assert len(cleaned) == 1
    assert audit["empty_descriptions_removed"] == 2


def test_inspect_dataset_metrics():
    """Verify the inspection dictionary output."""
    sample_data = pd.DataFrame([
        {"transaction_id": "TXN-1", "transaction_date": "2026-01-01", "description": "Coffee", "amount": 5.0, "transaction_type": "expense", "category": "Food & Dining"},
        {"transaction_id": "TXN-2", "transaction_date": "2026-01-02", "description": "Target", "amount": 45.0, "transaction_type": "expense", "category": "Shopping"},
    ])
    stats = inspect_dataset(sample_data)
    assert stats["total_records"] == 2
    assert "Food & Dining" in stats["category_distribution"]
    assert stats["duplicate_ids"] == 0
