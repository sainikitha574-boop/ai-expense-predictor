# SpendWise AI — Personal Expense Category Predictor
### AI-Powered Expense Classification, Budget Insights & Privacy-Focused Analytics

[![Python Version](https://img.shields.io/badge/Python-3.11-blue.svg)](https://python.org)
[![Streamlit App](https://img.shields.io/badge/Streamlit-1.66+-FF4B4B.svg)](https://streamlit.io)
[![Scikit-Learn](https://img.shields.io/badge/scikit--learn-1.3+-F7931E.svg)](https://scikit-learn.org)
[![Testing](https://img.shields.io/badge/pytest-15%20passed-brightgreen.svg)](https://pytest.org)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](#)

---

## 1. Project Overview

**SpendWise AI** is an end-to-end, privacy-preserving machine learning web application that automatically classifies personal banking transactions and expense descriptions into 13 standardized financial categories. Designed as a modern financial technology dashboard, SpendWise AI pairs a high-performance **TF-IDF + Logistic Regression** text classification pipeline with an interpretable **Rule-Based Baseline**, empirical model diagnostic tools, live cashflow budgeting analytics, and an interactive **Human-in-the-Loop** category correction workflow.

### Key Highlights
- **100% Local On-Device AI**: Zero transaction data or monetary amounts are sent to external cloud APIs or third parties.
- **Dual Classification Hierarchy**: Combines a deterministic rule engine with a machine learning pipeline capable of generalization across diverse merchant synonyms.
- **Uncertainty-Gated Automation**: Dynamic confidence score calibration automatically tags ambiguous transactions for manual human verification.
- **Strict Financial Separation**: Total income and expenses are computed independently, preventing accidental inflation of budget summaries.
- **Automatic PII Redaction**: Embedded regex filter strips credit card numbers, SSNs, routing/account numbers, and contact details from transaction inputs.

---

## 2. Problem Statement

Manual personal expense tracking is tedious, inconsistent, and often abandoned. While commercial banking platforms offer automated categorization, they present critical limitations:
1. **Privacy & Data Security Concerns**: Many commercial aggregators upload unredacted financial histories and merchant records to cloud services for profiling.
2. **Brittle Rigid Rules**: Simple keyword lookups fail on novel merchant names, atypical spelling, or abbreviated point-of-sale terminal narratives.
3. **Black-Box Overconfidence**: Unchecked machine learning models frequently miscategorize rare expenses without alerting the user.
4. **Lack of Correction Feedback**: Users are rarely empowered to override misclassified transactions or inspect comparative model performance.

**SpendWise AI solves these challenges** by providing an auditable, local-execution NLP classification engine with confidence thresholds, automated review queues, and instant manual override capability.

---

## 3. Technology Stack

- **Core & Runtime**: Python 3.11
- **Web Application & UI**: Streamlit 1.66+, Altair 6.3+, Vanilla CSS3
- **Data Manipulation & Analysis**: pandas 3.0+, NumPy 2.4+
- **Machine Learning & NLP**: scikit-learn 1.9+ (`TfidfVectorizer`, `LogisticRegression`, `Pipeline`)
- **Model Serialization**: Joblib 1.6+
- **Data Visualization & Diagnostics**: Matplotlib 3.11+, Seaborn 0.13+
- **Automated Testing**: pytest 9.1+

---

## 4. Project Directory Structure

```text
spendwise-ai/
│
├── app.py                         # Main Streamlit web application & UI
├── requirements.txt               # Pinned Python package dependencies
├── README.md                      # Comprehensive project documentation
├── .gitignore                     # Git ignore specifications
├── generate_notebooks.py          # Generator for Jupyter notebooks
│
├── data/
│   ├── synthetic_transactions.csv # 1,260 synthetic transaction records across 12 months
│   └── data_dictionary.csv        # Detailed schema, data types, and permitted values
│
├── models/
│   ├── expense_classifier.joblib  # Serialized scikit-learn ML Pipeline
│   └── evaluation_summary.json    # Verified evaluation metrics on held-out test split
│
├── notebooks/
│   ├── 01_data_exploration.ipynb  # EDA, distributions, missing value inspection
│   ├── 02_preprocessing.ipynb     # Text cleaning, duplicate filtering, stratified split
│   ├── 03_baseline_classifier.ipynb# Rule-based keyword matching benchmark
│   ├── 04_train_evaluate_model.ipynb# Pipeline training, hyperparameter tuning & diagnostics
│   └── 05_model_comparison.ipynb # Head-to-head Baseline vs. ML model evaluation
│
├── src/
│   ├── __init__.py                # Package initialization
│   ├── data_generator.py          # Synthetic dataset generator with controlled anomalies
│   ├── preprocessing.py           # Text normalization, data cleaning, and dataset auditing
│   ├── baseline.py                # Rule-based priority regex baseline classifier
│   ├── train_model.py             # Pipeline builder, model fitting, and metrics exporter
│   ├── predict.py                 # Single & batch inference engine with uncertainty thresholding
│   ├── evaluation.py              # Comparative diagnostics, confusion matrix & plot generator
│   ├── analytics.py               # Financial KPIs, monthly trends, and transaction filtering
│   └── privacy.py                 # PII redaction engine, CSV validation & privacy guarantees
│
├── tests/
│   ├── __init__.py                # Test package initialization
│   ├── test_preprocessing.py      # Preprocessing, normalization & anomaly handling tests
│   ├── test_prediction.py         # Baseline & ML prediction tests
│   └── test_validation.py         # Validation, privacy redaction & KPI calculation tests
│
├── assets/
│   ├── styles.css                 # Modern fintech CSS stylesheet
│   └── plots/                     # Diagnostic PNG figures (Confusion Matrix, F1, etc.)
│       ├── confusion_matrix.png
│       ├── per_category_f1.png
│       ├── model_comparison.png
│       └── category_distribution.png
│
└── docs/
    ├── FINAL_PROJECT_REPORT.md    # Formal academic capstone report
    └── PRESENTATION_OUTLINE.md    # Demonstration script & presentation walkthrough
```

---

## 5. Dataset Architecture & Spending Categories

SpendWise AI uses a programmatically generated, privacy-safe synthetic dataset spanning 12 calendar months (November 2025 to October 2026).

### 13 Predefined Categories
1. **Food & Dining**: Coffee shops, restaurants, fast food, bistros, bakeries.
2. **Groceries**: Supermarkets, produce markets, wholesale bulk clubs.
3. **Transportation**: Ridesharing, fuel stations, subway cards, tolls, transit tickets.
4. **Bills & Utilities**: Electric power, municipal water, mobile cellular, fiber internet.
5. **Healthcare**: Pharmacies, prescription copays, clinics, dental, urgent care.
6. **Entertainment**: Video streaming, cinemas, music platforms, gaming, live events.
7. **Education**: Online courses, textbooks, certifications, tutoring.
8. **Shopping**: Apparel, footwear, consumer electronics, department stores.
9. **Travel**: Domestic flights, hotel bookings, vacation rentals, car rentals.
10. **Personal Care**: Hair salons, skincare, cosmetics, gym memberships.
11. **Housing**: Residential lease, rent payments, HOA dues, home repair supplies.
12. **Income**: Bi-weekly payroll, freelance payouts, dividend distributions, client invoices.
13. **Other**: Post office, ATM surcharges, banking service fees, miscellaneous hardware.

### Controlled Data Quality Anomalies
To validate the robustness of the data cleaning pipeline, the raw dataset includes controlled edge cases:
- Missing and whitespace-only descriptions.
- Exact duplicate transactions.
- Inconsistent uppercase formatting and terminal noise.
- Non-positive or zero amounts.
- Unlabeled / missing category records.

---

## 6. Preprocessing & Modeling Pipeline

### Text Normalization Pipeline
1. Lowers text casing and trims leading/trailing whitespace.
2. Normalizes multiple spaces, tabs, and newline characters into single spaces.
3. Strips extraneous peripheral punctuation while preserving domain-critical tokens (e.g., `#`, hyphens, currency markers).
4. Sanitizes potential sensitive numbers (credit cards, account digits) via regex.

### Machine Learning Architecture
- **Feature Extraction**: `TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True, norm='l2')`
  - Sublinear term frequency damping reduces the dominance of repeated words.
  - Unigram and bigram extraction captures both merchant names (`starbucks`) and contextual phrases (`electric bill`, `air lines`).
- **Classification Engine**: `LogisticRegression(C=2.5, max_iter=1000, class_weight='balanced', solver='lbfgs')`
  - Balanced class weighting corrects for natural frequency imbalances between everyday groceries and periodic expenses like rent or travel.
  - Multi-class probability estimation via multinomial softmax provides calibrated confidence scores.

---

## 7. Model Evaluation & Benchmark Results

Evaluated on a **held-out 20% stratified test set (247 samples)** against the deterministic Rule-Based Baseline:

| Metric | Rule-Based Baseline | Machine Learning Model | Improvement |
| :--- | :---: | :---: | :---: |
| **Accuracy** | 96.36% | **100.00%** | **+3.64%** |
| **Macro Precision** | 96.12% | **100.00%** | **+3.88%** |
| **Macro Recall** | 94.20% | **100.00%** | **+5.80%** |
| **Macro F1-Score** | 94.81% | **100.00%** | **+5.19%** |

*Note: Metrics reflect performance on synthetic test transactions. Real-world bank feeds containing arbitrary user memos will yield expected lower confidence, triggering the built-in manual review workflow.*

---

## 8. Installation & Quickstart

### Prerequisites
- Python 3.11+
- Git (optional)

### Step 1: Clone or Navigate to Directory
```bash
cd C:\Users\vedhi\.gemini\antigravity-ide\scratch\spendwise-ai
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Generate Dataset
```bash
python -m src.data_generator
```

### Step 4: Train and Evaluate the Model
```bash
python -m src.train_model
```

### Step 5: Run Automated Tests
```bash
python -m pytest tests/
```

### Step 6: Launch the Streamlit Web Application
```bash
streamlit run app.py
```
Open your web browser at `http://localhost:8501`.

---

## 9. Interactive Demonstration Workflow

1. **Explore the Overview**:
   - Inspect live KPIs (Total Expenses, Total Income, Net Cashflow, Review Count).
   - Review the monthly spending trends and category distribution donut chart.
2. **Filter & Edit Transactions**:
   - Navigate to the **Transactions** ledger.
   - Search for specific merchants (e.g., `Kroger` or `Delta`).
   - Select a transaction and manually reassign its category. Notice that the ledger immediately marks the record as `Verified` / `Manually Corrected`, dynamically updating the analytics.
3. **Classify a Single Expense**:
   - Open **Categorize Expenses** tab.
   - Enter `Blue Bottle Coffee Roastery` with amount `$6.50`.
   - Click **Predict Category**. Observe the predicted category (`Food & Dining`), confidence score, and top alternative probabilities.
   - Enter an ambiguous or novel merchant name (e.g. `Corner Shop Supplies`); notice how the confidence meter reflects uncertainty and activates the review recommendation banner.
4. **Batch CSV Upload**:
   - Download the provided sample CSV template.
   - Upload the statement and click **Run Batch AI Classification**.
   - Review predictions, adjust confidence thresholds on the sidebar, and import records into the active ledger.
5. **Inspect Model Diagnostics**:
   - Visit **Model Evaluation** to review the confusion matrix heatmap, per-category F1 scores, and classification metrics.
6. **Verify Privacy Safeguards**:
   - Open **Privacy & About** and test the PII redaction input box with a dummy credit card number to confirm instantaneous regex masking.

---

## 10. Privacy, Ethics & Responsible AI Safeguards

- **No Third-Party AI API Dependency**: Unlike applications relying on remote proprietary LLM APIs, all models run within the local Python runtime.
- **Credential Safety**: The system operates exclusively on sanitized statements and synthetic data. Bank credentials or account passwords are never accepted.
- **Transparent Uncertainty**: The model outputs calibrated probability distributions rather than asserting unverified certainty.
- **Informational Disclaimer**: All outputs are clearly labeled as personal budgeting analytics, not financial or legal accounting advice.

---

## 11. Known Limitations & Future Work

- **Synthetic Domain Limitations**: Synthetic transactions feature standardized merchant naming conventions. Real-world card processors often append store numbers and regional codes (e.g., `SQ *CORNER BAKERY SFO CA`).
- **Cold-Start Novel Words**: For words completely unseen during training, TF-IDF representations revert to zero vectors, gracefully falling back to baseline rules or the manual review queue.
- **Future Enhancements**:
  - Integration of lightweight quantized on-device embeddings (e.g., MiniLM) for semantic similarity.
  - SQLite persistent ledger option for multi-user session persistence.
  - Automated recurring subscription detection (e.g., monthly Netflix or gym charges).

---

## 12. Authors & License

- **Project**: SpendWise AI — Personal Expense Category Predictor
- **Version**: 1.0.0
- **License**: MIT Open Source License
