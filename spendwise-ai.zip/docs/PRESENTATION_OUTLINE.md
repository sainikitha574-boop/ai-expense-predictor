# SpendWise AI — Project Demonstration & Presentation Outline
### Capstone Presentation & Defense Guide

**Time Allocation:** 10–15 Minutes  
**Audience:** Faculty Evaluators, Capstone Committee, Technical Peers  
**Product:** SpendWise AI — Personal Expense Category Predictor  

---

## Slide & Demonstration Breakdown

### 1. Title & Introduction (1 Minute)
- **Title**: SpendWise AI: Personal Expense Category Predictor
- **Sub-headline**: AI-Powered Expense Classification, Budget Insights & Privacy-Focused Analytics
- **Hook**: Managing personal finances is essential, but manual categorization is tedious, and commercial tools harvest user data via cloud servers.
- **Our Solution**: A 100% on-device, privacy-preserving NLP categorization web app that combines machine learning, deterministic rule baselines, and human-in-the-loop review queues.

---

### 2. Architecture & Tech Stack (1.5 Minutes)
- **Frontend / Application Framework**: Streamlit with custom CSS fintech design system (matte off-white/navy/teal palette, responsive cards, micro-interactions).
- **Core ML Pipeline**: `TfidfVectorizer(ngram_range=(1,2), sublinear_tf=True)` + `LogisticRegression(class_weight='balanced')`.
- **Baseline Engine**: Priority-ordered keyword & regex classifier (`src/baseline.py`).
- **Data Engineering**: 1,260 synthetic transactions spanning 12 months with controlled data-quality flaws (duplicates, missing text, non-positive amounts).
- **Local Privacy**: On-device execution with zero external AI API calls and integrated PII redaction.

---

### 3. Live Demonstration: Core Workflows (6 Minutes)

#### Step 1: Overview Dashboard
- Show the **4 Live KPI Cards**: Total Outbound Expenses, Total Inbound Income, Net Monthly Cashflow, and Transactions Awaiting Verification.
- Point out **strict financial separation**: Total income is calculated independently from expenses.
- Point out the **Monthly Spending Trend** and **Expense Distribution Donut Chart** rendered via Altair.
- Review the **Review Queue** displaying transactions below the certainty threshold.

#### Step 2: Interactive Categorization (Single Entry)
- Switch to **Categorize Expenses** tab.
- Enter a common expense: `Starbucks Coffee #1042` with `$5.75`.
- Click **Predict Category**.
  - Show the output: Category (`Food & Dining`), confidence meter (~95%+), and top alternative probabilities.
- Enter an ambiguous or novel merchant: `Mystery Hardware Kiosk` with `$22.00`.
  - Show the confidence meter drop below the sidebar threshold.
  - Show the dynamic badge change to **⚠️ Needs Manual Review**.
  - Demonstrate the manual override dropdown and click **Save to Ledger**.

#### Step 3: Batch Statement CSV Ingestion
- Switch to the **Batch Statement Upload** tab.
- Click **Download Sample CSV Template** to demonstrate export format.
- Upload a CSV statement and click **Run Batch AI Classification**.
- Show the classified preview table with confidence metrics and click **Import All into Active Ledger**.

#### Step 4: Transaction Ledger & Category Correction
- Navigate to **Transactions**.
- Demonstrate live search (e.g. typing `Kroger` or `Lyft`).
- Select a transaction in the **Edit Transaction Category** selector and change its category.
- Show that the record updates immediately, gets marked as `Verified` / `Manually Corrected`, and dynamically recalculates all dashboard KPIs and category totals.

#### Step 5: Empirical Model Evaluation
- Navigate to **Model Evaluation**.
- Show the **Confusion Matrix Heatmap**, **Per-Category F1 Bar Chart**, and **Baseline vs. ML Comparison Chart**.
- Emphasize that all numbers are computed from actual predictions on held-out test data (247 samples), not fabricated or hardcoded.
- Explain the key takeaway: ML achieves 100% accuracy on synthetic test data, outperforming the rule baseline (96.36%) by handling subtle merchant variations.

#### Step 6: Privacy & PII Redaction Console
- Navigate to **Privacy & About**.
- Type a phrase containing a mock credit card or account number: `Payment $50 using card 4532-1234-5678-9010`.
- Show instant real-time redaction into `[REDACTED_CARD]`.
- Demonstrate the **Reset Active Demo Session** button to reset state.

---

### 4. Technical Rigor & Automated Testing (2 Minutes)
- Switch to terminal and show the automated test suite results:
  ```bash
  python -m pytest tests/
  ```
  - 15 passed unit tests covering:
    - Preprocessing & text normalization (`test_preprocessing.py`)
    - Prediction inference, baseline fallback & thresholds (`test_prediction.py`)
    - CSV validation, PII redaction & financial KPIs (`test_validation.py`)

---

### 5. Summary, Limitations & Future Roadmap (1.5 Minutes)
- **Key Achievements**:
  - Full-stack AI system from raw data generation to interactive web deployment.
  - Reproducible, documented pipelines with zero data leakage.
  - Responsible AI implementation with uncertainty-guided human review.
- **Limitations**:
  - Synthetic data distributions do not encompass regional banking codes or informal merchant memos.
- **Future Enhancements**:
  - Quantized local transformer embeddings (e.g., MiniLM) for semantic representation.
  - SQLite persistent database storage for multi-user profiles.

---

### 6. Q&A Preparation (Common Evaluator Questions)

**Q1: Why did you choose Logistic Regression instead of a Deep Learning Transformer (e.g., BERT)?**  
*Answer:* Transaction descriptions are typically brief (3 to 8 words) with low syntactic complexity. TF-IDF paired with Logistic Regression provides sub-millisecond inference, operates on modest CPU hardware with zero GPU requirement, prevents overfitting on small vocabularies, and outputs interpretable probability estimates.

**Q2: How do you guarantee zero data leakage between training and testing?**  
*Answer:* The stratified train/test split is executed *before* any text vectorization. The `TfidfVectorizer` is fitted exclusively on `X_train`, ensuring test set vocabulary and inverse-document-frequency statistics never influence the model.

**Q3: How does the application handle an unseen merchant name?**  
*Answer:* If an input contains no known n-grams, TF-IDF produces a zero vector. The logistic regression model assigns near-uniform probabilities across classes, resulting in a low confidence score. The system automatically detects this via the confidence threshold and flags the transaction for manual user review.
