# SpendWise AI — Personal Expense Category Predictor
## Capstone Final Project Report

**Author:** AI/ML Capstone Project Team  
**Date:** October 2026  
**System Version:** 1.0.0  
**Repository:** `spendwise-ai/`

---

## Executive Summary

The **SpendWise AI** project addresses the persistent friction and privacy vulnerabilities inherent in modern personal finance management. While the automated categorization of bank transactions is critical for budget oversight, conventional tools frequently upload sensitive, unredacted transaction data to third-party cloud aggregators or rely on fragile regex heuristics that break down on novel merchant narratives.

This project delivers a complete, full-stack, on-device machine learning application that processes, normalizes, and classifies financial transaction descriptions into 13 distinct categories with zero cloud API reliance. Using an end-to-end **TF-IDF + Logistic Regression** pipeline trained on multi-month transaction streams and benchmarked against a deterministic rule-based baseline, SpendWise AI achieves superior multi-class categorization performance (100.0% test accuracy on synthetic benchmarks, compared to 96.36% for the rule baseline). Crucially, the platform incorporates an automated uncertainty-gating mechanism and a Human-in-the-Loop review queue, ensuring users maintain total sovereignty over their financial records.

---

## 1. Problem Formulation & Objectives

### 1.1 Problem Statement
Retail financial records typically present merchant information in unstructured, semi-standardized strings containing merchant names, terminal numbers, location codes, and abbreviations. Consumers attempting to maintain personal budgets encounter three distinct hurdles:
1. **Manual Categorization Fatigue**: Assigning hundreds of transactions monthly across diverse categories is unsustainable for most users.
2. **Privacy Vulnerabilities**: Mainstream commercial budgeting solutions often require OAuth banking logins or forward raw financial records to external cloud intelligence platforms.
3. **Inflexible Heuristics**: Traditional accounting tools employ rigid keyword lookups that cannot adapt to slight naming variations, slang, or new merchants.

### 1.2 Primary Project Objectives
- **Data Engineering**: Design and generate a realistic, multi-month synthetic personal banking dataset containing at least 1,000 transactions across 13 standardized spending categories, complete with controlled real-world data quality anomalies (duplicates, null descriptions, non-positive amounts).
- **Preprocessing Pipeline**: Implement a reproducible data cleaning and text normalization pipeline that guarantees zero data leakage between training and evaluation splits.
- **Dual Classification Hierarchy**: Construct both a transparent, priority-ordered **Rule-Based Baseline** and an optimized **Machine Learning Classifier** (scikit-learn Pipeline).
- **Empirical Diagnostics**: Evaluate both classifiers on identical held-out test records using standard metrics (Accuracy, Macro Precision, Macro Recall, Macro F1, and Confusion Matrices).
- **Interactive Fintech Web Interface**: Build an interactive web dashboard in Streamlit incorporating dynamic confidence meters, category override mechanisms, live cashflow budgeting analytics, and bulk CSV processing.
- **Privacy & Security by Design**: Implement local-only computation, automatic regex PII masking (credit card numbers, bank accounts, SSNs), and transparent uncertainty handling.

---

## 2. Dataset Design & Data Dictionary

### 2.1 Synthetic Generation Methodology
A purely synthetic dataset generation engine was engineered in `src/data_generator.py` to prevent any exposure of real personal banking credentials. The generator uses fixed random seeds (`seed=42`) and incorporates empirical consumer expenditure weights:
- Multi-month chronology: Spans 12 calendar months (November 2025 to October 2026).
- 13 Predefined Categories: Food & Dining, Groceries, Transportation, Bills & Utilities, Healthcare, Entertainment, Education, Shopping, Travel, Personal Care, Housing, Income, and Other.
- Controlled Real-World Flaws: Injected 8 null/whitespace descriptions, 15 whitespace-padded records, 6 non-positive amounts, 10 exact duplicates, and 4 unlabeled records to rigorously test the preprocessing pipeline.

### 2.2 Data Dictionary Summary
| Column | Type | Permitted Values | Description | ML Role |
| :--- | :--- | :--- | :--- | :--- |
| `transaction_id` | String | `TXN-XXXXX` | Unique record identifier | Metadata (Excluded from ML) |
| `transaction_date` | Date | `YYYY-MM-DD` | Date of occurrence | Temporal Aggregation |
| `description` | String | Freeform text | Merchant name & transaction memo | **Primary Feature** |
| `amount` | Float | Decimal > 0.00 | Monetary value in USD | Metric / Validation |
| `transaction_type` | String | `'expense'`, `'income'` | Direction of funds | Target Stratification |
| `category` | String | 13 Category strings | Assigned spending category | **Target Label** |

---

## 3. Data Cleaning & Text Preprocessing

The preprocessing module (`src/preprocessing.py`) executes six sequential transformation stages:
1. **Deduplication**: Identifies and drops exact duplicate records (`drop_duplicates(keep='first')`).
2. **Numerical Validation**: Converts amounts to numeric floats via safe coercion and rejects negative or zero values.
3. **Text Normalization**: 
   - Converts strings to lowercase.
   - Trims leading and trailing whitespace.
   - Collapses contiguous whitespace into single spaces.
   - Strips non-alphanumeric peripheral noise while preserving contextual tokens (e.g., `#`, hyphens).
4. **Target Label Cleaning**: Drops unlabelled records lacking ground truth categories.
5. **Date Standardization**: Validates and casts date strings into uniform `YYYY-MM-DD` format.
6. **Leakage Prevention**: Stratified train/test splitting (80/20) is conducted **before** TF-IDF vocabulary construction, ensuring no test token statistics inform feature extraction.

---

## 4. Model Architectures & Implementation

### 4.1 Rule-Based Baseline Classifier
Implemented in `src/baseline.py`, the baseline serves as an interpretable diagnostic benchmark. It organizes regex patterns into a documented priority hierarchy:
1. **Income Rules**: Matches payroll, direct deposits, salary, client invoices (evaluated first to guarantee fund separation).
2. **Housing Rules**: Matches rent, landlord, HOA dues, residential leases.
3. **Utility Rules**: Matches electric, power, fiber internet, water & sewer.
4. **Groceries vs. Dining**: Specific supermarket chains (`kroger`, `whole foods`, `supermarket`) take precedence over generic dining terms (`food`, `bistro`, `cafe`).
5. **Fallback**: If no rule matches, returns `Other` with a confidence score of `0.0`.

### 4.2 Machine Learning Pipeline (TF-IDF + Logistic Regression)
Implemented in `src/train_model.py`:
- **Vectorization**: `TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True, norm='l2')`. Sublinear term frequency damping ($1 + \log(\text{tf})$) mitigates the skew of repetitive merchant tokens, while unigrams and bigrams capture compound phrases.
- **Classifier**: `LogisticRegression(C=2.5, max_iter=1000, class_weight='balanced', solver='lbfgs')`. Balanced class weights counteract sample size disparities across categories.
- **Inference Engine**: `src/predict.py` extracts class probabilities via softmax, reporting the maximum probability as the prediction's estimated confidence. If the score falls below the user threshold (default 0.65), the transaction is automatically flagged for human review.

---

## 5. Comparative Evaluation & Experimental Results

Both classifiers were evaluated on the held-out test split of **247 records** across all 13 categories:

| Diagnostic Metric | Rule Baseline | Machine Learning Model | Delta ($\Delta$) |
| :--- | :---: | :---: | :---: |
| **Accuracy** | 96.36% | **100.00%** | **+3.64%** |
| **Macro Precision** | 96.12% | **100.00%** | **+3.88%** |
| **Macro Recall** | 94.20% | **100.00%** | **+5.80%** |
| **Macro F1-Score** | 94.81% | **100.00%** | **+5.19%** |

### Key Findings
1. **Generalization Over Rigid Rules**: While the rule baseline performed strongly on known keywords, it misclassified or failed on subtle variants (e.g., obscure store numbers or unusual suffixes), dropping recall to 94.20%. The ML model generalized seamlessly across these variations.
2. **Separation of Income and Outgoings**: Both models achieved 100% precision on Income records, verifying that payroll and deposits are never conflated with expense categories.
3. **Inference Latency**: Logistic regression inference executed in sub-millisecond time (<1.2ms per record), enabling real-time classification during single-item entry and rapid batch statement processing.

---

## 6. Software Architecture & User Interface

The application interface was engineered with **Streamlit** and customized with a bespoke CSS design system (`assets/styles.css`):
- **Overview Dashboard**: Real-time KPI stat cards displaying Total Expenses, Total Income, Net Cashflow, and Transactions Needing Review. Interactive Altair charts render monthly budget trends and category donut distributions.
- **Transactions Ledger**: Multi-column filtering by merchant, category, type, and date range. Features an inline category correction widget that allows users to reassign labels and marks records as `Verified`, immediately recalculating all downstream KPIs.
- **Categorize Expenses**: Dual-tab module supporting instant single-transaction classification (with confidence progress bars and top-3 probability tables) and bulk statement CSV ingestion with automated schema validation.
- **Model Evaluation**: Displays publication-ready diagnostic plots (Confusion Matrix Heatmap, Per-Category F1 Bar Chart, Baseline vs. ML Comparison) and full classification reports.
- **Privacy & Responsible AI**: Details local execution architecture, provides an interactive PII redaction test console, and includes a one-click session reset button.

---

## 7. Privacy, Ethical Considerations & Limitations

1. **Local Processing Guarantee**: All computations execute within the local Python process. No financial details or transaction notes are transmitted across external networks.
2. **Automatic PII Redaction**: Regex scanners intercept and redact 16-digit card numbers, SSNs, and routing numbers before text enters the vectorizer or ledger.
3. **Responsible Transparency**: Financial metrics are presented strictly as informational analytics rather than financial advice.
4. **Known Limitations**: Synthetic transaction data lacks the extreme noise and localized jargon of international card terminals (e.g., European SEPA narratives or Asian QR codes). Future iterations could incorporate lightweight local embeddings (e.g., Sentence-BERT) for cross-lingual transferability.

---

## 8. Conclusion

SpendWise AI demonstrates the successful integration of data engineering, natural language processing, modern software development, and privacy engineering into a unified financial technology product. By uniting an interpretable rule benchmark with an optimized machine learning pipeline and a user-centric review interface, the project provides a robust, transparent, and privacy-respecting blueprint for personal financial intelligence.
