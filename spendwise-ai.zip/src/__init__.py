"""SpendWise AI - Personal Expense Category Predictor package."""
__version__ = "1.0.0"
