"""SpendWise AI - Model Evaluation & Comparative Diagnostics

Evaluates Machine Learning models against Rule-Based Baselines on identical held-out test sets.
Generates comprehensive diagnostic metrics, classification reports, confusion matrices,
and publication-ready diagnostic charts.
"""

import os
from typing import Dict, Any, List, Optional, Tuple
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend for server environments
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    classification_report,
    confusion_matrix,
)

from .baseline import RuleBasedBaselineClassifier
from .predict import load_model
from .preprocessing import clean_dataset, prepare_training_data


def evaluate_models_on_test_data(
    data_path: Optional[str] = None,
    model: Optional[Any] = None,
) -> Dict[str, Any]:
    """Run full comparative evaluation of ML model and Baseline on held-out test data.
    
    Returns structured results for analytics and UI rendering.
    """
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if data_path is None:
        data_path = os.path.join(base_dir, "data", "synthetic_transactions.csv")

    raw_df = pd.read_csv(data_path)
    X_train, X_test, y_train, y_test = prepare_training_data(raw_df, test_size=0.2, random_state=42)

    if model is None:
        model = load_model()

    # ML Predictions
    y_pred_ml = model.predict(X_test)
    
    # Baseline Predictions
    baseline = RuleBasedBaselineClassifier()
    y_pred_bl = baseline.predict(list(X_test))

    unique_classes = sorted(list(np.unique(np.concatenate([y_test, y_pred_ml, y_pred_bl]))))

    # ML Metrics
    ml_acc = float(accuracy_score(y_test, y_pred_ml))
    ml_p, ml_r, ml_f1, _ = precision_recall_fscore_support(
        y_test, y_pred_ml, average="macro", zero_division=0
    )
    ml_report = classification_report(y_test, y_pred_ml, output_dict=True, zero_division=0)
    ml_cm = confusion_matrix(y_test, y_pred_ml, labels=unique_classes)

    # Baseline Metrics
    bl_acc = float(accuracy_score(y_test, y_pred_bl))
    bl_p, bl_r, bl_f1, _ = precision_recall_fscore_support(
        y_test, y_pred_bl, average="macro", zero_division=0
    )
    bl_report = classification_report(y_test, y_pred_bl, output_dict=True, zero_division=0)
    bl_cm = confusion_matrix(y_test, y_pred_bl, labels=unique_classes)

    # Per-category comparison
    per_cat_comparison = []
    for cat in unique_classes:
        ml_cat_stats = ml_report.get(cat, {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 0})
        bl_cat_stats = bl_report.get(cat, {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 0})
        per_cat_comparison.append({
            "category": cat,
            "support": ml_cat_stats.get("support", 0),
            "ml_precision": round(ml_cat_stats.get("precision", 0.0), 3),
            "ml_recall": round(ml_cat_stats.get("recall", 0.0), 3),
            "ml_f1": round(ml_cat_stats.get("f1-score", 0.0), 3),
            "baseline_precision": round(bl_cat_stats.get("precision", 0.0), 3),
            "baseline_recall": round(bl_cat_stats.get("recall", 0.0), 3),
            "baseline_f1": round(bl_cat_stats.get("f1-score", 0.0), 3),
            "f1_improvement": round(ml_cat_stats.get("f1-score", 0.0) - bl_cat_stats.get("f1-score", 0.0), 3),
        })

    return {
        "test_sample_count": len(X_test),
        "train_sample_count": len(X_train),
        "classes": unique_classes,
        "ml_metrics": {
            "accuracy": round(ml_acc, 4),
            "macro_precision": round(float(ml_p), 4),
            "macro_recall": round(float(ml_r), 4),
            "macro_f1": round(float(ml_f1), 4),
            "confusion_matrix": ml_cm.tolist(),
        },
        "baseline_metrics": {
            "accuracy": round(bl_acc, 4),
            "macro_precision": round(float(bl_p), 4),
            "macro_recall": round(float(bl_r), 4),
            "macro_f1": round(float(bl_f1), 4),
            "confusion_matrix": bl_cm.tolist(),
        },
        "per_category_comparison": per_cat_comparison,
        "y_true": list(y_test),
        "y_pred_ml": list(y_pred_ml),
        "y_pred_bl": list(y_pred_bl),
    }


def generate_evaluation_plots(
    eval_results: Dict[str, Any],
    output_dir: Optional[str] = None,
) -> Dict[str, str]:
    """Generate and save the four required diagnostic charts.
    
    1. Confusion Matrix Heatmap
    2. Per-Category F1-Score Bar Chart
    3. Baseline vs ML Overall Metric Comparison Chart
    4. Category Support / Distribution Chart
    
    Returns:
        Dict mapping plot_key to output image file path.
    """
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if output_dir is None:
        output_dir = os.path.join(base_dir, "assets", "plots")
    os.makedirs(output_dir, exist_ok=True)

    classes = eval_results["classes"]
    plot_paths = {}

    # Set clean styling
    plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
    plt.rcParams.update({"font.size": 10, "font.family": "sans-serif"})

    # --- Plot 1: ML Confusion Matrix Heatmap ---
    fig, ax = plt.subplots(figsize=(10, 8))
    cm = np.array(eval_results["ml_metrics"]["confusion_matrix"])
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=classes,
        yticklabels=classes,
        cbar=True,
        ax=ax,
    )
    ax.set_title("Machine Learning Classifier — Confusion Matrix", fontsize=14, pad=12, fontweight="bold")
    ax.set_xlabel("Predicted Spending Category", fontsize=11, labelpad=8)
    ax.set_ylabel("True Ground-Truth Category", fontsize=11, labelpad=8)
    plt.xticks(rotation=45, ha="right")
    plt.yticks(rotation=0)
    plt.tight_layout()
    p1 = os.path.join(output_dir, "confusion_matrix.png")
    fig.savefig(p1, dpi=200)
    plt.close(fig)
    plot_paths["confusion_matrix"] = p1

    # --- Plot 2: Per-Category F1-Score Bar Chart ---
    per_cat_df = pd.DataFrame(eval_results["per_category_comparison"])
    fig, ax = plt.subplots(figsize=(12, 6))
    x = np.arange(len(per_cat_df))
    width = 0.35
    ax.bar(x - width/2, per_cat_df["baseline_f1"], width, label="Baseline (Rules)", color="#94a3b8")
    ax.bar(x + width/2, per_cat_df["ml_f1"], width, label="ML Classifier (TF-IDF + LR)", color="#0d9488")
    ax.set_title("Per-Category F1-Score: Baseline vs ML Classifier", fontsize=14, pad=12, fontweight="bold")
    ax.set_xlabel("Spending Category", fontsize=11)
    ax.set_ylabel("F1 Score (0.0 to 1.0)", fontsize=11)
    ax.set_xticks(x)
    ax.set_xticklabels(per_cat_df["category"], rotation=45, ha="right")
    ax.set_ylim(0, 1.05)
    ax.legend(frameon=True)
    plt.tight_layout()
    p2 = os.path.join(output_dir, "per_category_f1.png")
    fig.savefig(p2, dpi=200)
    plt.close(fig)
    plot_paths["per_category_f1"] = p2

    # --- Plot 3: Overall Baseline vs ML Comparison ---
    fig, ax = plt.subplots(figsize=(8, 5))
    metrics_names = ["Accuracy", "Macro Precision", "Macro Recall", "Macro F1"]
    bl_scores = [
        eval_results["baseline_metrics"]["accuracy"],
        eval_results["baseline_metrics"]["macro_precision"],
        eval_results["baseline_metrics"]["macro_recall"],
        eval_results["baseline_metrics"]["macro_f1"],
    ]
    ml_scores = [
        eval_results["ml_metrics"]["accuracy"],
        eval_results["ml_metrics"]["macro_precision"],
        eval_results["ml_metrics"]["macro_recall"],
        eval_results["ml_metrics"]["macro_f1"],
    ]
    x_m = np.arange(len(metrics_names))
    w = 0.35
    b1 = ax.bar(x_m - w/2, bl_scores, w, label="Baseline (Rule-Based)", color="#64748b")
    b2 = ax.bar(x_m + w/2, ml_scores, w, label="ML Model (Logistic Regression)", color="#10b981")

    # Add data labels
    for rect in b1:
        h = rect.get_height()
        ax.annotate(f"{h:.2f}", xy=(rect.get_x() + rect.get_width() / 2, h),
                    xytext=(0, 3), textcoords="offset points", ha="center", va="bottom", fontsize=9)
    for rect in b2:
        h = rect.get_height()
        ax.annotate(f"{h:.2f}", xy=(rect.get_x() + rect.get_width() / 2, h),
                    xytext=(0, 3), textcoords="offset points", ha="center", va="bottom", fontsize=9, fontweight="bold")

    ax.set_title("Overall Model Performance Comparison", fontsize=14, pad=12, fontweight="bold")
    ax.set_ylabel("Metric Value (0.0 - 1.0)", fontsize=11)
    ax.set_xticks(x_m)
    ax.set_xticklabels(metrics_names)
    ax.set_ylim(0, 1.15)
    ax.legend(loc="lower right", frameon=True)
    plt.tight_layout()
    p3 = os.path.join(output_dir, "model_comparison.png")
    fig.savefig(p3, dpi=200)
    plt.close(fig)
    plot_paths["model_comparison"] = p3

    # --- Plot 4: Test Category Distribution / Support ---
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(per_cat_df["category"], per_cat_df["support"], color="#3b82f6", edgecolor="#1d4ed8")
    ax.set_title(f"Test Set Class Distribution (N={eval_results['test_sample_count']} Held-Out Records)", fontsize=14, pad=12, fontweight="bold")
    ax.set_xlabel("Category", fontsize=11)
    ax.set_ylabel("Number of Test Samples", fontsize=11)
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    p4 = os.path.join(output_dir, "category_distribution.png")
    fig.savefig(p4, dpi=200)
    plt.close(fig)
    plot_paths["category_distribution"] = p4

    return plot_paths
