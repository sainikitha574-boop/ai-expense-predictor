"""SpendWise AI - Preprocessing and Data Cleaning Pipeline

Provides reproducible data inspection, cleaning, text normalization,
and stratified train-test splitting without data leakage.
"""

import re
from typing import Dict, Any, Tuple
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split


def inspect_dataset(df: pd.DataFrame) -> Dict[str, Any]:
    """Inspect dataset dimensions, types, missingness, duplicates, and anomalies."""
    total_rows = len(df)
    duplicates_count = int(df.duplicated(subset=["transaction_id"]).sum())
    full_row_duplicates = int(df.duplicated().sum())

    missing_desc = int(df["description"].isna().sum() + (df["description"].astype(str).str.strip() == "").sum())
    missing_cat = int(df["category"].isna().sum()) if "category" in df.columns else 0

    # Amount anomalies
    amt_series = pd.to_numeric(df["amount"], errors="coerce")
    invalid_amounts = int(amt_series.isna().sum())
    non_positive_amounts = int((amt_series <= 0).sum())

    # Category counts
    cat_distribution = df["category"].value_counts(dropna=False).to_dict() if "category" in df.columns else {}

    # Transaction types
    type_distribution = df["transaction_type"].value_counts(dropna=False).to_dict() if "transaction_type" in df.columns else {}

    return {
        "total_records": total_rows,
        "total_columns": len(df.columns),
        "columns": list(df.columns),
        "column_types": {col: str(dtype) for col, dtype in df.dtypes.items()},
        "duplicate_ids": duplicates_count,
        "exact_duplicate_rows": full_row_duplicates,
        "missing_descriptions": missing_desc,
        "missing_categories": missing_cat,
        "invalid_amounts": invalid_amounts,
        "non_positive_amounts": non_positive_amounts,
        "category_distribution": cat_distribution,
        "transaction_type_distribution": type_distribution,
    }


def clean_text(text: Any) -> str:
    """Normalize raw transaction description text for NLP classification.
    
    Converts to lowercase, normalizes whitespace, strips punctuation noise
    while preserving meaningful alphanumeric merchant tokens, hyphens, and currency tags.
    """
    if text is None or pd.isna(text):
        return ""
    
    s = str(text).lower().strip()
    # Normalize multiple whitespace, newlines, and tabs
    s = re.sub(r"\s+", " ", s)
    # Remove leading/trailing non-alphanumeric noise (e.g. '---', '***')
    s = re.sub(r"^[^\w]+|[^\w]+$", "", s)
    # Normalize repeated punctuation characters
    s = re.sub(r"([!?,;])\1+", r"\1", s)
    return s.strip()


def clean_dataset(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, int]]:
    """Clean the raw transactions DataFrame according to documented rules.
    
    1. Removes duplicate rows (retaining first occurrence).
    2. Converts amounts safely to float and removes invalid/non-positive values (<= 0).
    3. Normalizes text descriptions and drops rows with empty descriptions.
    4. Drops rows with missing or undefined target categories (for model training).
    5. Validates and parses transaction dates.
    6. Ensures transaction_type is strictly 'expense' or 'income'.
    
    Returns:
        Tuple[pd.DataFrame, Dict[str, int]]: Cleaned DataFrame and audit report.
    """
    initial_count = len(df)
    audit = {
        "initial_records": initial_count,
        "duplicates_removed": 0,
        "invalid_amounts_removed": 0,
        "empty_descriptions_removed": 0,
        "missing_categories_removed": 0,
        "final_records": 0,
    }

    cleaned = df.copy()

    # Step 1: Remove exact duplicates and duplicate transaction IDs
    exact_dups = cleaned.duplicated().sum()
    cleaned = cleaned.drop_duplicates(keep="first").reset_index(drop=True)
    audit["duplicates_removed"] = int(exact_dups)

    # Step 2: Validate numerical amounts
    cleaned["amount"] = pd.to_numeric(cleaned["amount"], errors="coerce")
    invalid_mask = cleaned["amount"].isna() | (cleaned["amount"] <= 0)
    audit["invalid_amounts_removed"] = int(invalid_mask.sum())
    cleaned = cleaned[~invalid_mask].copy()

    # Step 3: Text normalization & handle missing descriptions
    cleaned["clean_description"] = cleaned["description"].apply(clean_text)
    empty_desc_mask = cleaned["clean_description"] == ""
    audit["empty_descriptions_removed"] = int(empty_desc_mask.sum())
    cleaned = cleaned[~empty_desc_mask].copy()

    # Step 4: Missing target category removal (only if category column exists)
    if "category" in cleaned.columns:
        cat_missing_mask = cleaned["category"].isna() | (cleaned["category"].astype(str).str.strip() == "")
        audit["missing_categories_removed"] = int(cat_missing_mask.sum())
        cleaned = cleaned[~cat_missing_mask].copy()

    # Step 5: Safe date parsing
    cleaned["transaction_date"] = pd.to_datetime(cleaned["transaction_date"], errors="coerce").dt.strftime("%Y-%m-%d")

    # Step 6: Validate transaction_type consistency
    if "transaction_type" not in cleaned.columns:
        cleaned["transaction_type"] = cleaned["category"].apply(
            lambda c: "income" if str(c).strip().lower() == "income" else "expense"
        )
    else:
        cleaned["transaction_type"] = cleaned["transaction_type"].str.lower().str.strip()
        cleaned["transaction_type"] = cleaned["transaction_type"].apply(
            lambda t: t if t in ["expense", "income"] else "expense"
        )

    cleaned = cleaned.reset_index(drop=True)
    audit["final_records"] = len(cleaned)

    return cleaned, audit


def prepare_training_data(
    df: pd.DataFrame,
    test_size: float = 0.2,
    random_state: int = 42
) -> Tuple[pd.Series, pd.Series, pd.Series, pd.Series]:
    """Perform a stratified train/test split on preprocessed descriptions and category labels.
    
    Splitting occurs BEFORE vectorization to prevent data leakage.
    """
    cleaned, _ = clean_dataset(df)
    
    # We classify expenses and income categories
    X = cleaned["clean_description"]
    y = cleaned["category"]

    # Stratified split ensures balanced representation across spending categories
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=test_size,
        random_state=random_state,
        stratify=y
    )

    return X_train, X_test, y_train, y_test
