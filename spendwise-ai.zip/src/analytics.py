"""SpendWise AI - Analytics & Financial Insights Engine

Calculates live dashboard KPIs, monthly aggregations, category breakdowns,
and provides multi-criteria filtering for the interactive user interface.
"""

from datetime import datetime
from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np


def calculate_kpis(df: pd.DataFrame) -> Dict[str, Any]:
    """Calculate key financial metrics from the active transactions dataset.
    
    Strictly separates expenses from income.
    """
    if df.empty:
        return {
            "total_expenses": 0.0,
            "total_income": 0.0,
            "net_savings": 0.0,
            "total_transactions": 0,
            "expense_count": 0,
            "income_count": 0,
            "top_category": "N/A",
            "top_category_amount": 0.0,
            "needs_review_count": 0,
            "current_month_spending": 0.0,
            "manually_corrected_count": 0,
        }

    # Ensure amount is numeric
    amounts = pd.to_numeric(df["amount"], errors="coerce").fillna(0.0)

    # Use final_category if available, otherwise category
    category_col = "final_category" if "final_category" in df.columns else "category"

    # Separate expenses vs income
    if "transaction_type" in df.columns:
        is_income = df["transaction_type"].str.lower() == "income"
    else:
        is_income = df[category_col].astype(str).str.lower() == "income"

    expense_df = df[~is_income]
    income_df = df[is_income]

    total_expenses = float(pd.to_numeric(expense_df["amount"], errors="coerce").sum())
    total_income = float(pd.to_numeric(income_df["amount"], errors="coerce").sum())
    net_savings = total_income - total_expenses

    # Top expense category
    if not expense_df.empty:
        cat_sums = expense_df.groupby(category_col)["amount"].sum()
        top_category = str(cat_sums.idxmax()) if not cat_sums.empty else "N/A"
        top_category_amount = float(cat_sums.max()) if not cat_sums.empty else 0.0
    else:
        top_category = "N/A"
        top_category_amount = 0.0

    # Review count
    if "needs_review" in df.columns:
        needs_review_count = int(df["needs_review"].sum())
    elif "review_status" in df.columns:
        needs_review_count = int((df["review_status"] == "Needs Review").sum())
    else:
        needs_review_count = 0

    # Manually corrected count
    if "manually_corrected" in df.columns:
        manually_corrected_count = int(df["manually_corrected"].sum())
    else:
        manually_corrected_count = 0

    # Current month's spending
    # Determine the latest date or month in the dataset
    dates = pd.to_datetime(df["transaction_date"], errors="coerce")
    valid_dates = dates.dropna()
    if not valid_dates.empty and not expense_df.empty:
        latest_month_str = valid_dates.max().strftime("%Y-%m")
        expense_dates = pd.to_datetime(expense_df["transaction_date"], errors="coerce").dt.strftime("%Y-%m")
        current_month_spending = float(expense_df[expense_dates == latest_month_str]["amount"].sum())
    else:
        current_month_spending = 0.0

    return {
        "total_expenses": round(total_expenses, 2),
        "total_income": round(total_income, 2),
        "net_savings": round(net_savings, 2),
        "total_transactions": len(df),
        "expense_count": len(expense_df),
        "income_count": len(income_df),
        "top_category": top_category,
        "top_category_amount": round(top_category_amount, 2),
        "needs_review_count": needs_review_count,
        "current_month_spending": round(current_month_spending, 2),
        "manually_corrected_count": manually_corrected_count,
    }


def get_monthly_trend(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate expenses and income by calendar month (YYYY-MM)."""
    if df.empty:
        return pd.DataFrame(columns=["month", "expenses", "income", "net_cashflow"])

    temp = df.copy()
    temp["amount"] = pd.to_numeric(temp["amount"], errors="coerce").fillna(0.0)
    temp["date"] = pd.to_datetime(temp["transaction_date"], errors="coerce")
    temp = temp.dropna(subset=["date"])
    temp["month"] = temp["date"].dt.strftime("%Y-%m")

    category_col = "final_category" if "final_category" in temp.columns else "category"
    if "transaction_type" in temp.columns:
        temp["is_income"] = temp["transaction_type"].str.lower() == "income"
    else:
        temp["is_income"] = temp[category_col].astype(str).str.lower() == "income"

    months = sorted(temp["month"].unique())
    trend_data = []

    for m in months:
        m_df = temp[temp["month"] == m]
        exp = float(m_df[~m_df["is_income"]]["amount"].sum())
        inc = float(m_df[m_df["is_income"]]["amount"].sum())
        trend_data.append({
            "month": m,
            "expenses": round(exp, 2),
            "income": round(inc, 2),
            "net_cashflow": round(inc - exp, 2),
        })

    return pd.DataFrame(trend_data)


def get_category_breakdown(df: pd.DataFrame) -> pd.DataFrame:
    """Compute total amount, percentage, count, and average spend per category."""
    if df.empty:
        return pd.DataFrame(columns=["category", "total_amount", "percentage", "count", "average_amount"])

    category_col = "final_category" if "final_category" in df.columns else "category"
    temp = df.copy()
    temp["amount"] = pd.to_numeric(temp["amount"], errors="coerce").fillna(0.0)

    # Filter out income so breakdown reflects expenses
    if "transaction_type" in temp.columns:
        temp = temp[temp["transaction_type"].str.lower() != "income"]
    else:
        temp = temp[temp[category_col].astype(str).str.lower() != "income"]

    if temp.empty:
        return pd.DataFrame(columns=["category", "total_amount", "percentage", "count", "average_amount"])

    grouped = temp.groupby(category_col).agg(
        total_amount=("amount", "sum"),
        count=("amount", "count"),
        average_amount=("amount", "mean"),
    ).reset_index().rename(columns={category_col: "category"})

    total_sum = grouped["total_amount"].sum()
    if total_sum > 0:
        grouped["percentage"] = (grouped["total_amount"] / total_sum) * 100
    else:
        grouped["percentage"] = 0.0

    grouped["total_amount"] = grouped["total_amount"].round(2)
    grouped["average_amount"] = grouped["average_amount"].round(2)
    grouped["percentage"] = grouped["percentage"].round(1)

    return grouped.sort_values(by="total_amount", ascending=False).reset_index(drop=True)


def filter_transactions(
    df: pd.DataFrame,
    search_query: str = "",
    selected_categories: Optional[List[str]] = None,
    transaction_type: str = "All",
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    sort_by: str = "Date (Newest)",
) -> pd.DataFrame:
    """Filter and sort the transactions DataFrame according to user queries."""
    if df.empty:
        return df.copy()

    filtered = df.copy()
    category_col = "final_category" if "final_category" in filtered.columns else "category"

    # Search query
    if search_query:
        query = search_query.strip().lower()
        desc_mask = filtered["description"].astype(str).str.lower().str.contains(query, regex=False)
        id_mask = filtered["transaction_id"].astype(str).str.lower().str.contains(query, regex=False)
        filtered = filtered[desc_mask | id_mask]

    # Category filter
    if selected_categories and len(selected_categories) > 0:
        filtered = filtered[filtered[category_col].isin(selected_categories)]

    # Transaction type filter
    if transaction_type in ["Expense", "expense"]:
        filtered = filtered[filtered["transaction_type"].str.lower() == "expense"]
    elif transaction_type in ["Income", "income"]:
        filtered = filtered[filtered["transaction_type"].str.lower() == "income"]

    # Date range filter
    if start_date:
        filtered = filtered[filtered["transaction_date"] >= str(start_date)]
    if end_date:
        filtered = filtered[filtered["transaction_date"] <= str(end_date)]

    # Sorting
    if sort_by == "Date (Newest)":
        filtered = filtered.sort_values(by="transaction_date", ascending=False)
    elif sort_by == "Date (Oldest)":
        filtered = filtered.sort_values(by="transaction_date", ascending=True)
    elif sort_by == "Amount (Highest)":
        filtered = filtered.sort_values(by="amount", ascending=False)
    elif sort_by == "Amount (Lowest)":
        filtered = filtered.sort_values(by="amount", ascending=True)

    return filtered.reset_index(drop=True)
