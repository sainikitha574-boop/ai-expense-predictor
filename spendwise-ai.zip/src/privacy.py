"""SpendWise AI - Privacy & Data Sanitization Engine

Implements local-only data privacy guarantees, PII masking (credit card numbers,
account digits, SSNs, phone numbers), input sanitation, and safe CSV validation.
"""

import re
from typing import Dict, Any, List, Tuple
import pandas as pd


# Regex patterns for common sensitive financial PII
PII_PATTERNS = [
    # Credit Card Numbers (13-19 digits, optionally spaced or hyphenated)
    (r"\b(?:\d[ -]*?){13,19}\b", "[REDACTED_CARD]"),
    # Social Security Numbers (e.g. 123-45-6789)
    (r"\b\d{3}[-]\d{2}[-]\d{4}\b", "[REDACTED_SSN]"),
    # Bank Account Numbers (e.g. 'ACCT: 123456789' or 'Account #12345')
    (r"(?i)\b(?:acct|account|acc|routing)\s*(?:#|no\.?|:)?\s*\d{6,17}\b", "[REDACTED_ACCOUNT]"),
    # Email addresses
    (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", "[REDACTED_EMAIL]"),
    # Phone numbers
    (r"\b(?:\+?1[-. ]?)?\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})\b", "[REDACTED_PHONE]"),
]


def sanitize_text(text: str) -> str:
    """Scan and redact sensitive personally identifiable information (PII).
    
    Protects user privacy by stripping potential credit cards, account numbers,
    SSNs, emails, and phone numbers before text enters ML inference or logging.
    """
    if not isinstance(text, str):
        return ""

    sanitized = text
    for pattern, replacement in PII_PATTERNS:
        sanitized = re.sub(pattern, replacement, sanitized)
    return sanitized.strip()


def validate_csv_upload(
    df: pd.DataFrame,
    max_rows: int = 5000,
) -> Tuple[bool, str, pd.DataFrame]:
    """Validate uploaded CSV structure, required columns, and data safety.
    
    Returns:
        Tuple[is_valid: bool, error_message: str, validated_df: pd.DataFrame]
    """
    if df.empty:
        return False, "The uploaded file contains no data rows.", df

    if len(df) > max_rows:
        return False, f"File exceeds maximum permitted limit of {max_rows} rows for demo processing.", df

    # Required column: description
    # Optional columns: amount, transaction_date, transaction_type
    columns_lower = {col.lower().strip(): col for col in df.columns}

    if "description" not in columns_lower:
        return False, "Missing required column 'description'. Please verify column header.", df

    desc_col = columns_lower["description"]
    validated = pd.DataFrame()
    validated["description"] = df[desc_col].astype(str).apply(sanitize_text)

    # Optional amount column
    if "amount" in columns_lower:
        amt_col = columns_lower["amount"]
        validated["amount"] = pd.to_numeric(df[amt_col], errors="coerce").fillna(0.0)
    else:
        validated["amount"] = 0.0

    # Optional date column
    if "transaction_date" in columns_lower:
        date_col = columns_lower["transaction_date"]
        validated["transaction_date"] = pd.to_datetime(df[date_col], errors="coerce").dt.strftime("%Y-%m-%d").fillna("2026-10-25")
    elif "date" in columns_lower:
        date_col = columns_lower["date"]
        validated["transaction_date"] = pd.to_datetime(df[date_col], errors="coerce").dt.strftime("%Y-%m-%d").fillna("2026-10-25")
    else:
        validated["transaction_date"] = "2026-10-25"

    # Optional type column
    if "transaction_type" in columns_lower:
        type_col = columns_lower["transaction_type"]
        validated["transaction_type"] = df[type_col].astype(str).str.lower().str.strip().apply(
            lambda t: "income" if t == "income" else "expense"
        )
    else:
        validated["transaction_type"] = "expense"

    # Generate transaction_id if missing
    if "transaction_id" in columns_lower:
        id_col = columns_lower["transaction_id"]
        validated["transaction_id"] = df[id_col].astype(str)
    else:
        validated["transaction_id"] = [f"UPL-{1000 + i}" for i in range(len(validated))]

    return True, "Validation successful.", validated


def get_privacy_audit_summary() -> Dict[str, Any]:
    """Return explicit statements regarding application data privacy protections."""
    return {
        "local_execution": "100% On-Device / Local Execution. No external cloud NLP APIs are called.",
        "zero_data_sharing": "Zero transaction descriptions or amounts are transmitted to third parties.",
        "credential_safety": "Zero bank logins, API keys, or account credentials required or stored.",
        "pii_redaction": "Automatic PII regex scanner masks card numbers, account tokens, and contact details.",
        "session_isolation": "Uploaded data resides exclusively in transient memory and can be cleared instantly.",
    }
