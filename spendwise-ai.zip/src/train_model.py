"""SpendWise AI - Machine Learning Model Training Pipeline

Trains a scikit-learn TF-IDF + Logistic Regression classification pipeline
on preprocessed transaction data, evaluates on a held-out test set,
and serializes the trained model with joblib.
"""

import json
import os
import sys
from typing import Dict, Any, Tuple
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, f1_score
from sklearn.pipeline import Pipeline

from .preprocessing import clean_dataset, prepare_training_data
from .baseline import RuleBasedBaselineClassifier


def build_pipeline() -> Pipeline:
    """Construct an end-to-end TF-IDF + Logistic Regression Pipeline."""
    vectorizer = TfidfVectorizer(
        ngram_range=(1, 2),
        min_df=2,
        sublinear_tf=True,
        norm="l2",
    )
    classifier = LogisticRegression(
        C=2.5,
        max_iter=1000,
        class_weight="balanced",
        random_state=42,
        solver="lbfgs",
    )
    return Pipeline([
        ("tfidf", vectorizer),
        ("clf", classifier),
    ])


def train_and_evaluate(
    data_path: str = None,
    model_save_path: str = None,
    metrics_save_path: str = None,
) -> Tuple[Pipeline, Dict[str, Any]]:
    """Train the model, evaluate against held-out test data, and persist artifacts."""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if data_path is None:
        data_path = os.path.join(base_dir, "data", "synthetic_transactions.csv")
    if model_save_path is None:
        model_save_path = os.path.join(base_dir, "models", "expense_classifier.joblib")
    if metrics_save_path is None:
        metrics_save_path = os.path.join(base_dir, "models", "evaluation_summary.json")

    if not os.path.exists(data_path):
        raise FileNotFoundError(
            f"Dataset not found at {data_path}. Please run `python -m src.data_generator` first."
        )

    print(f"Loading raw transactions from: {data_path}")
    raw_df = pd.read_csv(data_path)

    print("Cleaning dataset and preparing stratified split (80/20)...")
    cleaned_df, audit = clean_dataset(raw_df)
    X_train, X_test, y_train, y_test = prepare_training_data(raw_df, test_size=0.2, random_state=42)

    print(f"Training set size: {len(X_train)} samples")
    print(f"Test set size: {len(X_test)} samples")
    print(f"Number of classes: {len(y_train.unique())}")

    # Build and fit pipeline
    pipeline = build_pipeline()
    print("Fitting TF-IDF Vectorizer and Logistic Regression Pipeline...")
    pipeline.fit(X_train, y_train)

    # Evaluate ML Model
    y_pred = pipeline.predict(X_test)
    accuracy = float(accuracy_score(y_test, y_pred))
    macro_f1 = float(f1_score(y_test, y_pred, average="macro", zero_division=0))
    weighted_f1 = float(f1_score(y_test, y_pred, average="weighted", zero_division=0))

    # Evaluate Rule-based baseline on the exact same test split
    baseline = RuleBasedBaselineClassifier()
    baseline_preds = baseline.predict(list(X_test))
    baseline_accuracy = float(accuracy_score(y_test, baseline_preds))
    baseline_macro_f1 = float(f1_score(y_test, baseline_preds, average="macro", zero_division=0))

    class_rep = classification_report(y_test, y_pred, output_dict=True, zero_division=0)

    summary_metrics = {
        "model_type": "TF-IDF + Logistic Regression",
        "training_samples": len(X_train),
        "test_samples": len(X_test),
        "classes": sorted(list(y_train.unique())),
        "ml_accuracy": round(accuracy, 4),
        "ml_macro_f1": round(macro_f1, 4),
        "ml_weighted_f1": round(weighted_f1, 4),
        "baseline_accuracy": round(baseline_accuracy, 4),
        "baseline_macro_f1": round(baseline_macro_f1, 4),
        "classification_report": class_rep,
        "cleaning_audit": audit,
    }

    # Ensure output directories exist
    os.makedirs(os.path.dirname(model_save_path), exist_ok=True)
    os.makedirs(os.path.dirname(metrics_save_path), exist_ok=True)

    print(f"Saving trained model to {model_save_path}...")
    joblib.dump(pipeline, model_save_path)

    print(f"Saving evaluation summary to {metrics_save_path}...")
    with open(metrics_save_path, "w", encoding="utf-8") as f:
        json.dump(summary_metrics, f, indent=2)

    print("\n--- Model Training & Evaluation Summary ---")
    print(f"ML Model Accuracy:      {accuracy * 100:.2f}%")
    print(f"ML Model Macro F1:      {macro_f1 * 100:.2f}%")
    print(f"Baseline Rule Accuracy: {baseline_accuracy * 100:.2f}%")
    print(f"Baseline Macro F1:      {baseline_macro_f1 * 100:.2f}%")

    return pipeline, summary_metrics


def main():
    try:
        train_and_evaluate()
    except Exception as exc:
        print(f"Training failed: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
