"""SpendWise AI - Synthetic Transaction Dataset Generator

Generates realistic, privacy-safe personal banking and expense transactions
with multi-month distribution, realistic merchant templates, and controlled
data-quality anomalies for preprocessing demonstrations.
"""

import os
import random
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
import pandas as pd
import numpy as np

# Fixed seed for reproducibility
RANDOM_SEED = 42

CATEGORIES = [
    "Food & Dining",
    "Transportation",
    "Shopping",
    "Bills & Utilities",
    "Healthcare",
    "Entertainment",
    "Education",
    "Groceries",
    "Travel",
    "Personal Care",
    "Housing",
    "Income",
    "Other",
]

# Realistic Merchant / Description templates per category
CATEGORY_TEMPLATES: Dict[str, List[Tuple[str, float, float]]] = {
    "Food & Dining": [
        ("Starbucks Coffee #1042", 4.50, 18.00),
        ("Chipotle Mexican Grill lunch", 11.20, 26.50),
        ("McDonald's Drive-Thru", 6.80, 22.40),
        ("Subway Sandwiches Store 88", 7.50, 18.90),
        ("Olive Garden Italian Kitchen", 32.00, 85.00),
        ("Local Artisan Pizzeria slice", 14.00, 42.00),
        ("Blue Bottle Coffee Roastery", 5.75, 16.50),
        ("Panera Bread Bakery Cafe", 9.50, 28.00),
        ("Shake Shack Burgers & Fries", 12.00, 34.00),
        ("Downtown Sushi Bistro", 28.00, 95.00),
        ("Dunkin' Donuts Breakfast Combo", 4.20, 15.00),
        ("Thai Spice Restaurant dinner", 24.00, 68.00),
    ],
    "Groceries": [
        ("Kroger Supermarket Store #240", 35.00, 165.00),
        ("Whole Foods Market Organic Groceries", 45.00, 210.00),
        ("Trader Joe's Produce & Pantry", 28.00, 130.00),
        ("Walmart Supercenter Grocery dept", 30.00, 180.00),
        ("Aldi Food Market weekly grocery", 25.00, 110.00),
        ("Safeway Fresh Produce & Bakery", 32.00, 145.00),
        ("Costco Wholesale Bulk Provisions", 85.00, 340.00),
        ("Sprouts Farmers Market fresh vegetables", 22.00, 95.00),
        ("Target Grocery & Snacks", 18.00, 75.00),
        ("Local Asian Market fresh tofu & rice", 15.00, 62.00),
    ],
    "Transportation": [
        ("Uber Trip rideshare downtown", 12.50, 48.00),
        ("Lyft Ride to airport terminal", 18.00, 56.00),
        ("Shell Oil Gas Station fuel", 32.00, 78.00),
        ("Chevron Fuel Station unleaded", 28.00, 82.00),
        ("MTA Subway Metro Card refill", 15.00, 60.00),
        ("City Bus Transit ticket pass", 2.50, 25.00),
        ("Fastrak Toll Plaza automated payment", 4.50, 16.00),
        ("BP Fuel & Convenience gas pump", 30.00, 75.00),
        ("Downtown Parking Garage ticket", 8.00, 35.00),
        ("ExxonMobil gasoline refill", 34.00, 80.00),
    ],
    "Bills & Utilities": [
        ("Pacific Gas & Electric electric bill", 65.00, 195.00),
        ("ConEdison Utility power payment", 70.00, 210.00),
        ("Verizon Wireless monthly cell plan", 55.00, 140.00),
        ("AT&T Fiber Internet broadband bill", 50.00, 110.00),
        ("City Municipal Water & Sewer Dept", 35.00, 95.00),
        ("Comcast Xfinity Cable & WiFi", 60.00, 135.00),
        ("Waste Management municipal trash fee", 25.00, 55.00),
        ("National Grid Natural Gas heating", 40.00, 160.00),
        ("T-Mobile Cellular unlimited line", 45.00, 120.00),
    ],
    "Healthcare": [
        ("CVS Pharmacy prescription copay", 8.50, 55.00),
        ("Walgreens drug store medicine", 12.00, 62.00),
        ("Quest Diagnostics medical lab work", 35.00, 140.00),
        ("City Urgent Care clinic visit copay", 40.00, 120.00),
        ("Dr. Smith Family Dental cleaning", 50.00, 220.00),
        ("LensCrafters vision eyewear exam", 45.00, 180.00),
        ("Rite Aid Pharmacy allergy relief", 9.00, 38.00),
        ("Physical Therapy Associates session", 30.00, 90.00),
    ],
    "Entertainment": [
        ("Netflix Monthly Premium Subscription", 15.49, 22.99),
        ("Spotify Premium Music streaming", 10.99, 16.99),
        ("AMC Theatres Cinema tickets & popcorn", 18.00, 52.00),
        ("Steam Games video game download", 14.99, 69.99),
        ("Disney Plus annual subscription", 13.99, 139.99),
        ("PlayStation Network Store game purchase", 19.99, 79.99),
        ("Regal Cinemas movie admission", 14.00, 38.00),
        ("Ticketmaster Live Concert Pass", 45.00, 175.00),
        ("Audible Audiobooks monthly credit", 14.95, 29.90),
    ],
    "Education": [
        ("Coursera Plus Annual Online Specialization", 49.00, 399.00),
        ("Udemy Python & ML Masterclass course", 12.99, 34.99),
        ("University Campus Bookstore textbooks", 45.00, 210.00),
        ("edX Professional Certificate fee", 99.00, 299.00),
        ("Duolingo Super annual language subscription", 59.99, 83.99),
        ("Chegg Study homework assistance", 15.95, 19.95),
        ("O'Reilly Media Learning Platform", 49.00, 49.00),
        ("Academic Tutoring Center session fee", 35.00, 110.00),
    ],
    "Shopping": [
        ("Amazon.com retail merchandise order", 16.50, 185.00),
        ("Target Department Store home goods", 22.00, 140.00),
        ("Nike Factory Outlet running shoes", 55.00, 160.00),
        ("Zara Clothing fashion apparel", 35.00, 135.00),
        ("Apple Store electronics & cable", 29.00, 249.00),
        ("Best Buy consumer technology tech", 40.00, 310.00),
        ("H&M Casual Wear shirts & pants", 24.00, 89.00),
        ("IKEA Furniture home accessories", 35.00, 220.00),
        ("TJ Maxx Home Goods discount shopping", 18.00, 78.00),
    ],
    "Travel": [
        ("Delta Air Lines domestic flight ticket", 140.00, 480.00),
        ("Marriott Hotels overnight room stay", 115.00, 360.00),
        ("Airbnb vacation rental reservation", 95.00, 420.00),
        ("Hertz Car Rental airport reservation", 55.00, 190.00),
        ("American Airlines baggage fee & flight", 85.00, 390.00),
        ("Hilton Worldwide hotel booking", 120.00, 340.00),
        ("Expedia travel hotel and flight package", 130.00, 520.00),
        ("Amtrak Rail Passenger ticket trip", 35.00, 125.00),
    ],
    "Personal Care": [
        ("Supercuts Barber Haircut & styling", 22.00, 45.00),
        ("Sephora Cosmetics makeup & skincare", 28.00, 115.00),
        ("Great Clips Hair Salon trim", 19.00, 38.00),
        ("Planet Fitness monthly gym membership", 10.00, 25.00),
        ("Ulta Beauty personal cosmetic products", 24.00, 95.00),
        ("Massage Envy therapeutic body massage", 60.00, 125.00),
        ("Equinox Fitness Club monthly access", 150.00, 280.00),
        ("Bath & Body Works fragrance lotion", 15.00, 52.00),
    ],
    "Housing": [
        ("Apartment Management monthly rent payment", 1200.00, 2500.00),
        ("Landlord Residential ACH monthly lease", 1100.00, 2400.00),
        ("Homeowners Association monthly HOA dues", 150.00, 420.00),
        ("Home Depot hardware plumbing repair tools", 35.00, 190.00),
        ("Lowe's Home Improvement fixtures & paint", 40.00, 210.00),
    ],
    "Income": [
        ("TechCorp Global Payroll direct deposit salary", 2800.00, 5600.00),
        ("Apex Systems Bi-weekly employer salary", 2400.00, 4800.00),
        ("Freelance Web Design client payout", 350.00, 1600.00),
        ("Consulting Services direct ACH disbursement", 600.00, 2400.00),
        ("Vanguard Index Fund dividend distribution", 45.00, 350.00),
        ("Stripe Electronic client transfer invoice", 250.00, 1200.00),
    ],
    "Other": [
        ("ATM Cash Withdrawal local bank surcharge", 3.00, 5.00),
        ("USPS Post Office postage stamps & mail", 6.50, 32.00),
        ("Bank of America monthly service fee", 12.00, 15.00),
        ("FedEx Express package shipping label", 14.00, 42.00),
        ("City Clerk notary public document stamp", 10.00, 25.00),
        ("Hardware store miscellaneous nuts bolts", 5.00, 22.00),
    ],
}

# Relative weights of categories in real life spending
CATEGORY_WEIGHTS: Dict[str, float] = {
    "Food & Dining": 0.18,
    "Groceries": 0.16,
    "Transportation": 0.12,
    "Bills & Utilities": 0.10,
    "Shopping": 0.10,
    "Entertainment": 0.08,
    "Housing": 0.05,
    "Healthcare": 0.05,
    "Personal Care": 0.04,
    "Education": 0.03,
    "Travel": 0.03,
    "Income": 0.04,  # Bi-weekly or monthly salary occurrences
    "Other": 0.02,
}


def generate_synthetic_transactions(
    num_records: int = 1250,
    start_date: datetime = datetime(2025, 11, 1),
    end_date: datetime = datetime(2026, 10, 25),
    introduce_anomalies: bool = True,
    seed: int = RANDOM_SEED,
) -> pd.DataFrame:
    """Generate realistic synthetic transactions with controlled data quality issues."""
    random.seed(seed)
    np.random.seed(seed)

    records: List[Dict] = []
    total_days = max(1, (end_date - start_date).days)
    categories = list(CATEGORY_WEIGHTS.keys())
    weights = [CATEGORY_WEIGHTS[c] for c in categories]

    txn_counter = 10001

    for _ in range(num_records):
        cat = random.choices(categories, weights=weights, k=1)[0]
        templates = CATEGORY_TEMPLATES[cat]
        template, min_amt, max_amt = random.choice(templates)

        # Realistic random amount with 2 decimal places
        amount = round(random.uniform(min_amt, max_amt), 2)

        # Random date within timeframe
        random_days = random.randint(0, total_days)
        txn_date = (start_date + timedelta(days=random_days)).strftime("%Y-%m-%d")

        txn_type = "income" if cat == "Income" else "expense"

        # Subtle variations in description to mimic real transaction streams
        desc_variants = [
            template,
            template.upper() if random.random() < 0.1 else template,
            f"{template} - REF#{random.randint(100, 999)}" if random.random() < 0.15 else template,
        ]
        chosen_desc = random.choice(desc_variants)

        records.append({
            "transaction_id": f"TXN-{txn_counter}",
            "transaction_date": txn_date,
            "description": chosen_desc,
            "amount": amount,
            "transaction_type": txn_type,
            "category": cat,
        })
        txn_counter += 1

    df = pd.DataFrame(records)

    if introduce_anomalies:
        # Controlled data quality flaws for preprocessing demonstrations:
        # 1. Missing / NaN descriptions (~8 rows)
        missing_desc_idx = random.sample(range(len(df)), 8)
        for idx in missing_desc_idx:
            df.at[idx, "description"] = np.nan if random.random() < 0.5 else "   "

        # 2. Whitespace / inconsistent formatting (~15 rows)
        ws_idx = random.sample(range(len(df)), 15)
        for idx in ws_idx:
            desc = str(df.at[idx, "description"])
            df.at[idx, "description"] = f"   {desc.strip()}    "

        # 3. Invalid or negative amounts (~6 rows)
        invalid_amt_idx = random.sample(range(len(df)), 6)
        for i, idx in enumerate(invalid_amt_idx):
            if i % 2 == 0:
                df.at[idx, "amount"] = -1 * abs(df.at[idx, "amount"])  # Negative amount
            else:
                df.at[idx, "amount"] = 0.00  # Zero amount

        # 4. Duplicate rows (~10 rows)
        dup_sources = random.sample(range(len(df)), 10)
        duplicates = df.iloc[dup_sources].copy()
        df = pd.concat([df, duplicates], ignore_index=True)

        # 5. Missing category label (~4 rows)
        missing_cat_idx = random.sample(range(len(df)), 4)
        for idx in missing_cat_idx:
            df.at[idx, "category"] = np.nan

    # Sort chronologically by date
    df["date_sort"] = pd.to_datetime(df["transaction_date"], errors="coerce")
    df = df.sort_values(by=["date_sort", "transaction_id"]).drop(columns=["date_sort"]).reset_index(drop=True)

    return df


def main():
    """CLI Entrypoint to generate and save synthetic transactions."""
    output_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
    os.makedirs(output_dir, exist_ok=True)
    raw_path = os.path.join(output_dir, "synthetic_transactions.csv")

    print(f"Generating synthetic transactions with seed={RANDOM_SEED}...")
    df = generate_synthetic_transactions(num_records=1250, introduce_anomalies=True)
    df.to_csv(raw_path, index=False)
    print(f"Successfully generated {len(df)} transactions and saved to {raw_path}")
    print("\nSample records:")
    print(df.head(5))
    print("\nCategory distribution:")
    print(df["category"].value_counts(dropna=False))


if __name__ == "__main__":
    main()
