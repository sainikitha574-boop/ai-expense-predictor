"""SpendWise AI - Model Inference & Expense Prediction Engine

Loads the trained Pipeline safely, computes calibrated probability estimates,
evaluates uncertainty thresholds for manual review recommendations,
and supports single-transaction and batch inference.
"""

import os
from typing import Dict, List, Optional, Any
import joblib
import numpy as np
import pandas as pd
from .preprocessing import clean_text


class ModelNotFoundError(Exception):
    """Raised when the trained model artifact does not exist on disk."""
    pass


class ModelLoadError(Exception):
    """Raised when loading the model artifact fails due to incompatibility or corruption."""
    pass


def get_default_model_path() -> str:
    """Return default filesystem path to the serialized model artifact."""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_dir, "models", "expense_classifier.joblib")


def load_model(model_path: Optional[str] = None):
    """Safely load the scikit-learn Pipeline from disk with informative error feedback."""
    if model_path is None:
        model_path = get_default_model_path()

    if not os.path.exists(model_path):
        raise ModelNotFoundError(
            f"Trained model not found at '{model_path}'. "
            "Please train the model first by running: python -m src.train_model"
        )

    try:
        model = joblib.load(model_path)
        return model
    except Exception as exc:
        raise ModelLoadError(
            f"Failed to load model from '{model_path}'. Error details: {exc}"
        ) from exc


def predict_single(
    description: str,
    amount: Optional[float] = None,
    model: Optional[Any] = None,
    threshold: float = 0.65,
) -> Dict[str, Any]:
    """Classify a single transaction description with probability estimation and review flag.
    
    Args:
        description: Merchant or transaction description text.
        amount: Optional transaction amount (used for context / sanity verification).
        model: Optional pre-loaded pipeline instance.
        threshold: Confidence threshold below which manual review is recommended.
        
    Returns:
        Dict with predicted_category, confidence, needs_review, review_reason, top_classes.
    """
    cleaned_desc = clean_text(description)
    if not cleaned_desc:
        return {
            "description": description,
            "cleaned_description": "",
            "amount": amount,
            "predicted_category": "Other",
            "confidence": 0.0,
            "confidence_percentage": "0.0%",
            "needs_review": True,
            "review_status": "Needs Review",
            "review_reason": "Empty or whitespace-only description cannot be classified reliably.",
            "top_probabilities": [],
        }

    if model is None:
        model = load_model()

    # Model inference
    classes = list(model.classes_)
    probs = model.predict_proba([cleaned_desc])[0]
    
    # Get highest probability class
    best_idx = int(np.argmax(probs))
    predicted_category = str(classes[best_idx])
    confidence = float(probs[best_idx])
    
    # Top 3 probability distribution
    sorted_indices = np.argsort(probs)[::-1][:3]
    top_probabilities = [
        {"category": str(classes[idx]), "probability": round(float(probs[idx]), 4)}
        for idx in sorted_indices
    ]

    # Review status determination
    needs_review = False
    review_reason = "Model predicted category with high confidence."
    review_status = "Auto-Approved"

    if confidence < threshold:
        needs_review = True
        review_status = "Needs Review"
        review_reason = (
            f"Confidence score ({confidence * 100:.1f}%) is below the {threshold * 100:.0f}% "
            f"certainty threshold. Second likely category: {top_probabilities[1]['category']} "
            f"({top_probabilities[1]['probability'] * 100:.1f}%)."
        )

    return {
        "description": description,
        "cleaned_description": cleaned_desc,
        "amount": amount,
        "predicted_category": predicted_category,
        "confidence": round(confidence, 4),
        "confidence_percentage": f"{confidence * 100:.1f}%",
        "needs_review": needs_review,
        "review_status": review_status,
        "review_reason": review_reason,
        "top_probabilities": top_probabilities,
    }


def predict_batch(
    df: pd.DataFrame,
    description_col: str = "description",
    model: Optional[Any] = None,
    threshold: float = 0.65,
) -> pd.DataFrame:
    """Classify a batch of transactions represented in a pandas DataFrame.
    
    Appends predicted_category, confidence, and review_status columns.
    """
    if df.empty:
        return df.copy()

    if model is None:
        model = load_model()

    result_df = df.copy()
    cleaned_texts = result_df[description_col].apply(clean_text)

    classes = list(model.classes_)
    probs = model.predict_proba(cleaned_texts)

    best_indices = np.argmax(probs, axis=1)
    confidences = np.max(probs, axis=1)

    predicted_categories = [classes[idx] for idx in best_indices]
    needs_review_flags = confidences < threshold
    review_statuses = [
        "Needs Review" if flag else "Auto-Approved" for flag in needs_review_flags
    ]

    result_df["predicted_category"] = predicted_categories
    result_df["confidence"] = np.round(confidences, 4)
    result_df["needs_review"] = needs_review_flags
    result_df["review_status"] = review_statuses
    result_df["final_category"] = predicted_categories
    result_df["manually_corrected"] = False

    return result_df
