"""SpendWise AI - Rule-Based Baseline Classifier

Provides a deterministic keyword and regular-expression based rule engine
to establish an interpretable classification baseline prior to machine learning.
"""

import re
from typing import Dict, List, Optional, Tuple, Any
import pandas as pd
from .preprocessing import clean_text

# Ordered rule definitions. High-specificity merchant/domain tokens are evaluated first.
# Format: Category -> (List of primary regex/keywords, priority rank)
RULE_SPECIFICATIONS: List[Tuple[str, List[str]]] = [
    # 1. Income (High priority to strictly separate funds)
    (
        "Income",
        [
            r"\bsalary\b", r"\bpayroll\b", r"\bdividend\b", r"\bdirect deposit\b",
            r"\bpayout\b", r"\bdisbursement\b", r"\bconsulting fee\b", r"\bemployer\b",
            r"\bclient invoice\b", r"\btransfer invoice\b"
        ]
    ),
    # 2. Housing (High cost, distinct terms)
    (
        "Housing",
        [
            r"\brent\b", r"\blandlord\b", r"\bapartment lease\b", r"\bhoa dues\b",
            r"\bhomeowners association\b", r"\bresidential lease\b", r"\bhome depot\b",
            r"\blowe'?s\b", r"\bplumbing repair\b"
        ]
    ),
    # 3. Bills & Utilities
    (
        "Bills & Utilities",
        [
            r"\belectric bill\b", r"\bpower payment\b", r"\bconedison\b", r"\bpge\b",
            r"\bpacific gas\b", r"\bverizon\b", r"\bat&t\b", r"\bfiber internet\b",
            r"\bbroadband\b", r"\bwater & sewer\b", r"\bxfinity\b", r"\bcomcast\b",
            r"\bnational grid\b", r"\bt-mobile\b", r"\bmunicipal trash\b", r"\butility\b"
        ]
    ),
    # 4. Groceries (Distinguished from general Food & Dining)
    (
        "Groceries",
        [
            r"\bgrocery\b", r"\bgroceries\b", r"\bsupermarket\b", r"\bwhole foods\b",
            r"\btrader joe\b", r"\bkroger\b", r"\bsafeway\b", r"\baldi\b", r"\bcostco\b",
            r"\bsprouts\b", r"\bfarmers market\b", r"\bfresh produce\b", r"\bpantry\b"
        ]
    ),
    # 5. Food & Dining
    (
        "Food & Dining",
        [
            r"\bstarbucks\b", r"\bcoffee\b", r"\bchipotle\b", r"\bmcdonald\b",
            r"\bsubway\b", r"\bpizzeria\b", r"\bpizza\b", r"\bbakery\b", r"\bcafe\b",
            r"\bbistro\b", r"\brestaurant\b", r"\bdonuts\b", r"\bshake shack\b",
            r"\bolive garden\b", r"\blunch\b", r"\bdinner\b", r"\bbreakfast\b"
        ]
    ),
    # 6. Transportation
    (
        "Transportation",
        [
            r"\buber\b", r"\blyft\b", r"\brideshare\b", r"\btaxi\b", r"\bcab\b",
            r"\bshell oil\b", r"\bchevron\b", r"\bgas station\b", r"\bgasoline\b",
            r"\bfuel\b", r"\bmetro card\b", r"\bsubway metro\b", r"\bcity bus\b",
            r"\btransit\b", r"\btoll\b", r"\bparking\b", r"\bexxon\b", r"\bbp fuel\b"
        ]
    ),
    # 7. Travel
    (
        "Travel",
        [
            r"\bflight\b", r"\bairline\b", r"\bdelta air\b", r"\bamerican airlines\b",
            r"\bhotel\b", r"\bmarriott\b", r"\bhilton\b", r"\bairbnb\b",
            r"\bhertz\b", r"\bcar rental\b", r"\bexpedia\b", r"\bamtrak\b"
        ]
    ),
    # 8. Healthcare
    (
        "Healthcare",
        [
            r"\bpharmacy\b", r"\bcvs\b", r"\bwalgreens\b", r"\bprescription\b",
            r"\bmedicine\b", r"\blab work\b", r"\bquest diagnostics\b",
            r"\burgent care\b", r"\bdental\b", r"\bdoctor\b", r"\bclinic\b",
            r"\beyewear\b", r"\btherapy\b"
        ]
    ),
    # 9. Education
    (
        "Education",
        [
            r"\bcoursera\b", r"\budemy\b", r"\btextbook\b", r"\bbookstore\b",
            r"\bedx\b", r"\bduolingo\b", r"\bchegg\b", r"\btutoring\b",
            r"\bonline course\b", r"\bcampus\b", r"\btuition\b"
        ]
    ),
    # 10. Entertainment
    (
        "Entertainment",
        [
            r"\bnetflix\b", r"\bspotify\b", r"\btheatre\b", r"\bcinema\b",
            r"\bmovie\b", r"\bsteam games\b", r"\bvideo game\b", r"\bdisney plus\b",
            r"\bplaystation\b", r"\bticketmaster\b", r"\bconcert\b", r"\baudible\b"
        ]
    ),
    # 11. Personal Care
    (
        "Personal Care",
        [
            r"\bhaircut\b", r"\bbarber\b", r"\bsalon\b", r"\bsephora\b",
            r"\bcosmetics\b", r"\bgym\b", r"\bplanet fitness\b", r"\bfitness club\b",
            r"\bulta beauty\b", r"\bmassage\b", r"\bskincare\b"
        ]
    ),
    # 12. Shopping
    (
        "Shopping",
        [
            r"\bamazon\b", r"\btarget\b", r"\bnike\b", r"\bzara\b",
            r"\bapple store\b", r"\bbest buy\b", r"\bh&m\b", r"\bikea\b",
            r"\bshoes\b", r"\bclothing\b", r"\bapparel\b", r"\bhome goods\b"
        ]
    ),
    # 13. Fallback / Other
    (
        "Other",
        [
            r"\batm cash\b", r"\bwithdrawal\b", r"\bpost office\b", r"\busps\b",
            r"\bfedex\b", r"\bservice fee\b", r"\bnotary\b"
        ]
    ),
]


class RuleBasedBaselineClassifier:
    """Keyword and pattern-matching baseline classifier for transaction categorization."""

    def __init__(self):
        self.rules: List[Tuple[str, List[re.Pattern]]] = []
        self._compile_rules()

    def _compile_rules(self):
        """Pre-compile regular expressions for fast matching."""
        self.rules = []
        for category, patterns in RULE_SPECIFICATIONS:
            compiled = [re.compile(p, re.IGNORECASE) for p in patterns]
            self.rules.append((category, compiled))

    def predict_single(self, description: str) -> Dict[str, Any]:
        """Predict the category for a single transaction description.
        
        Returns:
            Dict containing predicted_category, matched_keyword, confidence, and rule_fired.
        """
        cleaned = clean_text(description)
        if not cleaned:
            return {
                "predicted_category": "Other",
                "matched_keyword": "None (Empty input)",
                "confidence": 0.0,
                "rule_matched": False,
            }

        for category, pattern_list in self.rules:
            for pattern in pattern_list:
                match = pattern.search(cleaned)
                if match:
                    return {
                        "predicted_category": category,
                        "matched_keyword": match.group(0),
                        "confidence": 1.0,
                        "rule_matched": True,
                    }

        # If no explicit rule matches, classify as 'Other' with 0.0 confidence
        return {
            "predicted_category": "Other",
            "matched_keyword": "No rule match",
            "confidence": 0.0,
            "rule_matched": False,
        }

    def predict(self, descriptions: List[str]) -> List[str]:
        """Classify a list of transaction descriptions."""
        return [self.predict_single(d)["predicted_category"] for d in descriptions]


def get_baseline_classifier() -> RuleBasedBaselineClassifier:
    """Factory helper to get an instance of the baseline classifier."""
    return RuleBasedBaselineClassifier()
