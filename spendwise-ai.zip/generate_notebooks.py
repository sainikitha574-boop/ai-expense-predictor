"""Helper script to generate the 5 clean Jupyter notebooks for SpendWise AI."""

import json
import os

NOTEBOOKS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "notebooks")
os.makedirs(NOTEBOOKS_DIR, exist_ok=True)

def create_nb(cells):
    return {
        "cells": cells,
        "metadata": {
            "language_info": {
                "name": "python",
                "version": "3.11.0"
            },
            "orig_nbformat": 4
        },
        "nbformat": 4,
        "nbformat_minor": 2
    }

def md_cell(text):
    return {
        "cell_type": "markdown",
        "metadata": {},
        "source": [line + "\n" for line in text.strip().split("\n")]
    }

def code_cell(code, output_text=None):
    cell = {
        "cell_type": "code",
        "execution_count": 1,
        "metadata": {},
        "outputs": [],
        "source": [line + "\n" for line in code.strip().split("\n")]
    }
    if output_text:
        cell["outputs"].append({
            "name": "stdout",
            "output_type": "stream",
            "text": [line + "\n" for line in output_text.strip().split("\n")]
        })
    return cell

# --- Notebook 1: Data Exploration ---
nb1_cells = [
    md_cell("""# SpendWise AI — Notebook 01: Exploratory Data Analysis (EDA)
### Personal Expense Category Predictor
**Objective:** Inspect raw synthetic transactions, analyze column distributions, detect data quality anomalies, and visualize category frequencies and class imbalance."""),
    code_cell("""import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
pd.set_option('display.max_columns', None)

DATA_PATH = os.path.join("..", "data", "synthetic_transactions.csv")
df_raw = pd.read_csv(DATA_PATH)
print(f"Loaded raw dataset with {len(df_raw)} records and {len(df_raw.columns)} columns.")"""),
    md_cell("### 1. Dataset Dimensions & Schema"),
    code_cell("""print("Dataset Information:")
df_raw.info()
print("\nFirst 5 Records:")
display(df_raw.head())"""),
    md_cell("### 2. Anomaly & Missing Value Detection"),
    code_cell("""print("Missing Values Per Column:")
print(df_raw.isna().sum())

print("\nDuplicate Records:")
print(f"Exact row duplicates: {df_raw.duplicated().sum()}")
print(f"Duplicate transaction IDs: {df_raw.duplicated(subset=['transaction_id']).sum()}")

# Amount validation
invalid_amts = df_raw[pd.to_numeric(df_raw['amount'], errors='coerce') <= 0]
print(f"Non-positive / invalid amounts count: {len(invalid_amts)}")"""),
    md_cell("### 3. Category Frequency & Class Distribution"),
    code_cell("""fig, ax = plt.subplots(figsize=(10, 5))
cat_counts = df_raw['category'].value_counts(dropna=False)
cat_counts.plot(kind='bar', color='#0d9488', ax=ax, edgecolor='#115e59')
ax.set_title("Distribution of Transaction Categories in Raw Dataset", fontsize=14, fontweight='bold')
ax.set_xlabel("Category")
ax.set_ylabel("Transaction Count")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()"""),
    md_cell("### 4. Amount Distribution by Category"),
    code_cell("""valid_df = df_raw[pd.to_numeric(df_raw['amount'], errors='coerce') > 0].copy()
valid_df['amount'] = valid_df['amount'].astype(float)

fig, ax = plt.subplots(figsize=(12, 6))
sns.boxplot(data=valid_df[valid_df['transaction_type'] == 'expense'], x='category', y='amount', ax=ax, palette='Blues_r')
ax.set_yscale('log')
ax.set_title("Expense Amount Distribution (Log Scale)", fontsize=14, fontweight='bold')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()""")
]

# --- Notebook 2: Preprocessing ---
nb2_cells = [
    md_cell("""# SpendWise AI — Notebook 02: Data Preprocessing Pipeline
### Personal Expense Category Predictor
**Objective:** Implement reproducible data cleaning, text normalization, anomaly filtering, and prepare training/testing splits without data leakage."""),
    code_cell("""import sys
import os
sys.path.append("..")

import pandas as pd
from src.preprocessing import clean_text, clean_dataset, inspect_dataset, prepare_training_data

DATA_PATH = os.path.join("..", "data", "synthetic_transactions.csv")
df_raw = pd.read_csv(DATA_PATH)
print("Initial Dataset Inspection:")
initial_stats = inspect_dataset(df_raw)
for k, v in initial_stats.items():
    if not isinstance(v, dict):
        print(f"  {k}: {v}")"""),
    md_cell("### 1. Cleaning & Anomaly Resolution Pipeline"),
    code_cell("""cleaned_df, audit_log = clean_dataset(df_raw)
print("Cleaning Audit Report:")
for metric, count in audit_log.items():
    print(f"  {metric}: {count}")

print(f"\nFinal clean records count: {len(cleaned_df)}")"""),
    md_cell("### 2. Text Normalization Demonstration"),
    code_cell("""sample_descriptions = [
    "   STARBUCKS COFFEE #1042   ",
    "Kroger Supermarket Store #240 --- REF#921",
    "***Netflix Monthly Premium Subscription***",
    "Uber   Trip   Downtown"
]

print("Text Normalization Comparison:")
for raw_desc in sample_descriptions:
    print(f"RAW:   '{raw_desc}'")
    print(f"CLEAN: '{clean_text(raw_desc)}'\n")"""),
    md_cell("### 3. Stratified Train-Test Split (Zero Data Leakage)"),
    code_cell("""X_train, X_test, y_train, y_test = prepare_training_data(df_raw, test_size=0.2, random_state=42)

print(f"Training set: {len(X_train)} samples")
print(f"Test set:     {len(X_test)} samples")
print("\nTraining category distribution:")
print(y_train.value_counts(normalize=True).round(3))""")
]

# --- Notebook 3: Baseline Classifier ---
nb3_cells = [
    md_cell("""# SpendWise AI — Notebook 03: Rule-Based Baseline Classifier
### Personal Expense Category Predictor
**Objective:** Construct an interpretable, deterministic keyword matching rule engine to set a benchmark before applying machine learning."""),
    code_cell("""import sys
import os
sys.path.append("..")

import pandas as pd
from src.baseline import RuleBasedBaselineClassifier
from src.preprocessing import prepare_training_data
from sklearn.metrics import classification_report, accuracy_score

baseline = RuleBasedBaselineClassifier()
print("Rule-based baseline initialized with ordered category hierarchy.")"""),
    md_cell("### 1. Testing Rule-Based Predictions on Sample Transactions"),
    code_cell("""test_samples = [
    "Starbucks Coffee Downtown",
    "Whole Foods Organic Grocery",
    "Chevron Gas Station Unleaded",
    "TechCorp Bi-Weekly Salary Deposit",
    "Unknown obscure corner kiosk",
    "Monthly apartment rent payment"
]

for desc in test_samples:
    res = baseline.predict_single(desc)
    print(f"'{desc}' -> Predicted: {res['predicted_category']} (Keyword: '{res['matched_keyword']}', Conf: {res['confidence']})")"""),
    md_cell("### 2. Evaluating Baseline on Held-Out Test Data"),
    code_cell("""DATA_PATH = os.path.join("..", "data", "synthetic_transactions.csv")
raw_df = pd.read_csv(DATA_PATH)
X_train, X_test, y_train, y_test = prepare_training_data(raw_df, test_size=0.2, random_state=42)

y_pred_baseline = baseline.predict(list(X_test))

print(f"Baseline Accuracy: {accuracy_score(y_test, y_pred_baseline):.4f}\n")
print("Baseline Classification Report:")
print(classification_report(y_test, y_pred_baseline, zero_division=0))""")
]

# --- Notebook 4: Train & Evaluate Model ---
nb4_cells = [
    md_cell("""# SpendWise AI — Notebook 04: Machine Learning Model Training & Evaluation
### Personal Expense Category Predictor
**Objective:** Build, optimize, and evaluate a TF-IDF + Logistic Regression classification Pipeline on the held-out test split, and serialize the trained model."""),
    code_cell("""import sys
import os
sys.path.append("..")

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import joblib

from src.train_model import build_pipeline, train_and_evaluate
from src.preprocessing import prepare_training_data

pipeline, summary = train_and_evaluate()
print("Training and evaluation completed successfully.")"""),
    md_cell("### 1. Model Evaluation Metrics"),
    code_cell("""print(f"Machine Learning Accuracy:  {summary['ml_accuracy'] * 100:.2f}%")
print(f"Machine Learning Macro F1:  {summary['ml_macro_f1'] * 100:.2f}%")
print(f"Training Samples Count:    {summary['training_samples']}")
print(f"Held-Out Test Samples:     {summary['test_samples']}")"""),
    md_cell("### 2. Confusion Matrix Heatmap"),
    code_cell("""DATA_PATH = os.path.join("..", "data", "synthetic_transactions.csv")
raw_df = pd.read_csv(DATA_PATH)
_, X_test, _, y_test = prepare_training_data(raw_df, test_size=0.2, random_state=42)

y_pred = pipeline.predict(X_test)
classes = sorted(list(y_test.unique()))
cm = confusion_matrix(y_test, y_pred, labels=classes)

fig, ax = plt.subplots(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=classes, yticklabels=classes, ax=ax)
ax.set_title("Confusion Matrix — Logistic Regression Model", fontsize=14, fontweight='bold')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()""")
]

# --- Notebook 5: Model Comparison ---
nb5_cells = [
    md_cell("""# SpendWise AI — Notebook 05: Baseline vs. Machine Learning Model Comparison
### Personal Expense Category Predictor
**Objective:** Perform a rigorous diagnostic comparison between the rule-based baseline and the scikit-learn classifier, inspect edge cases, and evaluate uncertainty thresholding."""),
    code_cell("""import sys
import os
sys.path.append("..")

import pandas as pd
import matplotlib.pyplot as plt
from src.evaluation import evaluate_models_on_test_data

eval_results = evaluate_models_on_test_data()
ml_m = eval_results['ml_metrics']
bl_m = eval_results['baseline_metrics']

comparison_df = pd.DataFrame([
    {"Metric": "Accuracy", "Baseline (Rules)": bl_m['accuracy'], "ML Classifier (TF-IDF + LR)": ml_m['accuracy']},
    {"Metric": "Macro Precision", "Baseline (Rules)": bl_m['macro_precision'], "ML Classifier (TF-IDF + LR)": ml_m['macro_precision']},
    {"Metric": "Macro Recall", "Baseline (Rules)": bl_m['macro_recall'], "ML Classifier (TF-IDF + LR)": ml_m['macro_recall']},
    {"Metric": "Macro F1-Score", "Baseline (Rules)": bl_m['macro_f1'], "ML Classifier (TF-IDF + LR)": ml_m['macro_f1']},
])
display(comparison_df)"""),
    md_cell("### 1. Comparative Metrics Visualization"),
    code_cell("""fig, ax = plt.subplots(figsize=(8, 5))
x = range(len(comparison_df))
width = 0.35
ax.bar([i - width/2 for i in x], comparison_df['Baseline (Rules)'], width, label='Baseline', color='#94a3b8')
ax.bar([i + width/2 for i in x], comparison_df['ML Classifier (TF-IDF + LR)'], width, label='ML Classifier', color='#10b981')
ax.set_xticks(list(x))
ax.set_xticklabels(comparison_df['Metric'])
ax.set_ylim(0, 1.15)
ax.set_title("Baseline vs Machine Learning Performance", fontsize=14, fontweight='bold')
ax.legend()
plt.tight_layout()
plt.show()"""),
    md_cell("### 2. Per-Category F1 Breakdown"),
    code_cell("""per_cat_df = pd.DataFrame(eval_results['per_category_comparison'])
display(per_cat_df[['category', 'support', 'baseline_f1', 'ml_f1', 'f1_improvement']])""")
]

# Write all 5 notebooks
notebooks = {
    "01_data_exploration.ipynb": nb1_cells,
    "02_preprocessing.ipynb": nb2_cells,
    "03_baseline_classifier.ipynb": nb3_cells,
    "04_train_evaluate_model.ipynb": nb4_cells,
    "05_model_comparison.ipynb": nb5_cells,
}

for filename, cells in notebooks.items():
    filepath = os.path.join(NOTEBOOKS_DIR, filename)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(create_nb(cells), f, indent=2)
    print(f"Created notebook: {filepath}")

print("All 5 Jupyter notebooks generated successfully.")
